# Assumptions and provenance

Synthetic: True

Source labels describe the supplied evidence; review does not turn estimates into measurements.

- Collision: per-link axis-aligned bounding boxes.
- Inertia: uniform solid cuboid approximation; not measured inertia.
- Gravity (m/s²): [0, 0, -9.81]; timestep (s): 0.001.
- Contact solref: [0.02, 1] (numerical assumption).
- Root: fixed to world at reviewed root_pose.
- Parent/child contact policy: MuJoCo native filtering; static-root children may collide with the root.
- Explicit excluded pairs: [].

| Item | Value | Source | Note |
| --- | --- | --- | --- |
| base mass (kg) | 0.5 | estimated | Synthetic assumption |
| base sliding friction | unknown; simulator uses 0.8 | simulation default | not measured |
| base geometry | meshes/base.obj | estimated | Grouped without deformation. base (estimated): Synthetic test geometry; vertices in link coordinates, metres |
| arm mass (kg) | 0.1 | estimated | Synthetic assumption |
| arm sliding friction | unknown; simulator uses 0.8 | simulation default | not measured |
| arm geometry | meshes/arm.obj | estimated | Grouped without deformation. arm (estimated): Synthetic test geometry; vertices in link coordinates, metres |
| hinge connection | base → arm (revolute) | user_supplied | Reviewed synthetic hinge, not inferred from photos Review: Synthetic hinge review |
| hinge damping | 0.2 | estimated |  |
| hinge drive | kp=5.0 Nm/rad; torque limit=2.0 Nm | estimated |  |

Torsional/rolling friction, contact settings and box inertia are simulation assumptions.
Read the full JSON records for frames, limits, notes and retained provenance.

No measured physical accuracy or calibrated hardware response is established.
