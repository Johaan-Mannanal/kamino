Upload the four JPEGs in upload-1024 together. Native cutouts and masks preserve decoded source pixels; upload JPEGs are padded, resampled and compressed.
Manual masks are approximate, not measured silhouettes. View 07 overlaps both pins; view 03 disambiguates them. View 08 has a soft rear outline.
No physical dimensions are established by these photos. No reconstruction run or mesh-quality improvement is claimed.
