import json,hashlib,zipfile
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).resolve().parent
destination=root.parent/'2026-10-25-manual-followup-evidence.zip'
assert not destination.exists(),'Do not overwrite a finalized addendum archive'
excluded={'MANIFEST.json','D03-after-human-confirmation.native.txt'}
files=[p for p in root.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts]
payload={p.relative_to(root).as_posix():p.read_bytes() for p in sorted(files)}
manifest={'date_local':'2026-10-25','timezone':'America/Los_Angeles','created_at_utc':datetime.now(timezone.utc).isoformat(),'tested_application_sha':'a834763920176f34cafd07a49aa5ea9064bdc545','original_results_untouched':True,'omissions':['unrelated browser chrome/bookmarks in the local raw native UIA dump; focused verbatim extract is included','original evidence/export ZIPs are referenced by immutable hashes rather than duplicated'],'files':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in payload.items()]}
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
(root/'MANIFEST.json').write_bytes(manifest_bytes)
with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,data in payload.items(): z.writestr(name,data)
    z.writestr('MANIFEST.json',manifest_bytes)
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None
    for item in manifest['files']:
        data=z.read(item['path'])
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
digest=hashlib.sha256(destination.read_bytes()).hexdigest()
destination.with_suffix('.zip.sha256').write_text(digest+'  '+destination.name+'\n',encoding='ascii')
print(json.dumps({'archive':str(destination),'bytes':destination.stat().st_size,'payload_files':len(payload),'sha256':digest,'crc_and_manifest_verified':True},indent=2))
