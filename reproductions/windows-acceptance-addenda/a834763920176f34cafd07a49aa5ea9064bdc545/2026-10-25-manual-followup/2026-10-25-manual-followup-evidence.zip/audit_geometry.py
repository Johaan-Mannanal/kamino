"""Read-only geometry/runtime audit for the unchanged final B bundle."""
from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
import numpy as np
import trimesh
root=Path(__file__).resolve().parent
original=root.parents[2]/'windows-acceptance-results/a834763920176f34cafd07a49aa5ea9064bdc545'
relocated=Path('C:/Users/srija/.codex/visualizations/2026/10/25/01a17239-e03d-74c3-97d6-0df134ce5686/kamino-final-relocated-B')
asset=json.loads((relocated/'asset.json').read_text(encoding='utf-8'))
mesh=trimesh.load(relocated/'meshes/visual.obj',force='mesh',process=False)
scales=np.array(asset['sizing_result']['scale_factors'])
source=np.array(asset['sizing_result']['source_extents_input_units'])
error=float(np.max(np.abs(mesh.extents-scales*source)))
assert np.all(scales==scales[0]) and error<1e-7
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(original/'exports/B.zip')=='f8d4d57bc924940eef6f8ba06316797b754d7c7369d854b3926252b628ad53cf'
assert sha(relocated/'meshes/visual.obj')=='e1437620a734d028a9abd9fc9b0c99be5ea455e5bbacac3f50ac3ca4eeda66e7'
refs=[]
for node in ET.parse(relocated/'scene.xml').iter():
    if 'file' in node.attrib:
        target=(relocated/node.attrib['file']).resolve()
        assert target.is_relative_to(relocated.resolve()) and target.is_file()
        refs.append({'relative_path':node.attrib['file'],'sha256':sha(target)})
out={'original_final_B_zip_sha256':sha(original/'exports/B.zip'),'relocated_scene':str(relocated/'scene.xml'),'relocated_scene_sha256':sha(relocated/'scene.xml'),'visual_mesh_sha256':sha(relocated/'meshes/visual.obj'),'local_asset_references':refs,'saved_orientation_degrees':asset['orientation'],'source_extents':source.tolist(),'equal_scale_factors':scales.tolist(),'exported_full_extents_m':mesh.extents.tolist(),'maximum_extent_error_m':error,'audit_tolerance_m':1e-7,'saved_mass':asset['properties']['mass_kg'],'saved_friction':asset['properties']['sliding_friction'],'physical_accuracy':'unverified; derived diameter about 29.8 mm differs from historical 57 mm estimate; no independent axis stretch'}
(root/'geometry-audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
