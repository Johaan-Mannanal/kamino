import json,hashlib,subprocess
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).resolve().parent
before=json.loads((root/'preservation-before.json').read_text(encoding='utf-8'))
results=[]
for item in before['files']:
    p=Path(item['path']); digest=hashlib.sha256(p.read_bytes()).hexdigest()
    results.append({'path':item['path'],'bytes':p.stat().st_size,'sha256':digest,'unchanged':digest==item['sha256'] and p.stat().st_size==item['bytes']})
checkout=Path(before['pinned_checkout'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip()
status=subprocess.check_output(['git','status','--short'],cwd=checkout,text=True)
out={'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'files':results,'all_original_files_unchanged':all(x['unchanged'] for x in results),'pinned_head':head,'pinned_status_short':status}
(root/'preservation-after.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
assert out['all_original_files_unchanged']
assert head==before['pinned_head'] and not status.strip()
print(f'{len(results)} original files unchanged; pinned application HEAD and worktree unchanged.')
