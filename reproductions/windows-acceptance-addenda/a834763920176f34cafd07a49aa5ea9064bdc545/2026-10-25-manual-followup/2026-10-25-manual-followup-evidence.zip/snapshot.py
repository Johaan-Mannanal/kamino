import json,sys,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
request=urllib.request.Request('http://127.0.0.1:8002/api/jobs/c25fcbbd-cec8-4065-ab36-d829fd9be888',headers={'Authorization':'Bearer ui-acceptance-only'})
with opener.open(request,timeout=30) as response: job=json.load(response)
(root/'api').mkdir(exist_ok=True)
(root/'api'/f'{sys.argv[1]}-job.json').write_text(json.dumps(job,indent=2),encoding='utf-8')
print(json.dumps({k:job[k] for k in ['id','status','input_revision','active_attempt_id']},indent=2))
