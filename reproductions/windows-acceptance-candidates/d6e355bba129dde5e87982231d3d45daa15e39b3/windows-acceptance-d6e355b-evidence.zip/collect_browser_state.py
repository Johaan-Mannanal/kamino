import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
DATA = ROOT.parents[1] / 'd6' / 'outputs' / 'ui-integration' / 'browser'
IDS = {
    'can': '7f021e56-94b6-43f9-bc35-ef226a5b0a7a',
    'failed': '07f5637a-23fb-4487-9a07-b96d5f497241',
    'recovered': 'a83eed6c-396a-4f33-b1f4-6aa974317d8d',
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

jobs = {}
for label, ident in IDS.items():
    request = Request(f'http://127.0.0.1:8003/api/jobs/{ident}', headers={'Authorization': 'Bearer ui-acceptance-only'})
    with urlopen(request) as response:
        jobs[label] = json.load(response)
    (ROOT / f'browser-final-{label}-job.json').write_text(json.dumps(jobs[label], indent=2) + '\n')

assert jobs['can']['status'] == 'completed'
assert jobs['can']['input_revision'] == 5
assert len(jobs['can']['attempts']) == 2
assert jobs['failed']['status'] == 'failed'
assert jobs['failed']['error']['code'] == 'provider_failed'
assert jobs['recovered']['status'] == 'awaiting_properties'
assert jobs['recovered']['synthetic'] is True
photo_hashes = {}
for i in range(3):
    name = f'uploads/{i:02}.jpg'
    values = {label: digest(DATA / ident / name) for label, ident in IDS.items()}
    assert len(set(values.values())) == 1
    photo_hashes[name] = values
comparison = {'sha': 'd6e355bba129dde5e87982231d3d45daa15e39b3', 'ui_reconstruction_failure': 'PASS', 'ui_explicit_fresh_upload_recovery': 'PASS', 'photos_byte_identical': photo_hashes, 'jobs': IDS, 'mock_cube_quality_not_accepted': True}
(ROOT / 'R04-browser-summary.json').write_text(json.dumps(comparison, indent=2) + '\n')
print(json.dumps(comparison, indent=2))
