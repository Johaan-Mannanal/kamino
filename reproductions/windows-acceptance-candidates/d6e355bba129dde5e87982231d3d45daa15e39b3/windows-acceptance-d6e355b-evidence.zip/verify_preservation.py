import json
import hashlib
from pathlib import Path
from datetime import datetime, UTC
import subprocess

root = Path(__file__).parent
before = json.loads((root / 'preservation-before.json').read_text())
changed, missing, errors = [], [], []
verified = 0
for name, expected in before.items():
    p = Path(chr(92) * 2 + '?' + chr(92) + name.replace('/', chr(92)))
    if not p.is_file():
        missing.append(name)
        continue
    try:
        with p.open('rb') as stream:
            actual = hashlib.file_digest(stream, 'sha256').hexdigest()
        verified += 1
        if actual != expected:
            changed.append(dict(path=name, expected=expected, actual=actual))
    except OSError as exc:
        errors.append(dict(path=name, error=str(exc)))

workspace = Path('C:/Users/srija/calhacks-arm')
checkouts = {}
for label, path in [('original_application',workspace/'outputs/acceptance-checkouts/kamino-a834763'),('candidate', workspace/'outputs/d6')]:
    head = subprocess.run(['git','-C',str(path),'rev-parse','HEAD'],capture_output=True,text=True)
    status = subprocess.run(['git','-C',str(path),'status','--short'],capture_output=True,text=True)
    checkouts[label] = dict(path=str(path),head=head.stdout.strip(),status=status.stdout.strip(),head_exit=head.returncode,status_exit=status.returncode,stderr=head.stderr+status.stderr)
result = dict(checked_at_utc=datetime.now(UTC).isoformat(),baseline_file_count=len(before),verified_files=verified,changed=changed,missing=missing,errors=errors,checkouts=checkouts)
(root/'preservation-after.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))

