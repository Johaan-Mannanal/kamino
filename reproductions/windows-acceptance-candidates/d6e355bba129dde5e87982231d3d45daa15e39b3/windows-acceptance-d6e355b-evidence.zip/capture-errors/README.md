These provisional files accidentally retained the initial screenshot because a lexical var shadowed the freshly assigned global state.
They are INVALID angle/time evidence. Corrected evidence is captured with explicit globalThis.freshNative and checked by independent review.
No original a834763 records are involved.
