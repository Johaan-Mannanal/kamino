import hashlib, json, time, zipfile, io, shutil, sys, traceback
from pathlib import Path
from uuid import UUID
from fastapi.testclient import TestClient
from tools import ui_acceptance_server as server
from tools.ui_acceptance_fixture import import_can
from photo2sim.api.store import JobStore
import mujoco, numpy as np, trimesh

SHA='d6e355bba129dde5e87982231d3d45daa15e39b3'
ROOT=Path(__file__).resolve().parent
DATA=Path.cwd()/'outputs/ui-integration/api-review'
ARCHIVE=Path.cwd().parent/'windows-acceptance-results/a834763920176f34cafd07a49aa5ea9064bdc545/can-fixture.zip'
ROOT.mkdir(parents=True,exist_ok=True)
results={'sha':SHA,'transport':'in-process TestClient using supplied guarded acceptance build_app; no production settings or credentials','checks':{}}
def save(name,value):
 (ROOT/(name+'.json')).write_text(json.dumps(value,indent=2,default=str)+'\n')
def digest(b):return hashlib.sha256(b).hexdigest()
def ok(r,status=200):
 assert r.status_code==status,(r.status_code,r.text)
 return r.json()
def terminal(c,ident,states):
 end=time.monotonic()+90
 while time.monotonic()<end:
  j=ok(c.get(f'/api/jobs/{ident}'))
  if j['status'] in states:return j
  time.sleep(.05)
 raise AssertionError(j)
def review_can(c,ident):
 orientation={'x_deg':90.0,'y_deg':0.0,'z_deg':0.0}
 j=ok(c.patch(f'/api/jobs/{ident}/orientation',json=orientation))
 inv=ok(c.get(f'/api/jobs/{ident}/geometry'))
 save(f'{ident}-inventory',inv)
 target='2c8782adb8e2deeaf252e5c1ba0611a71c7d5c729c01e41927f770430fc2edf7'
 assert target in [p['id'] for p in inv['islands']]
 j=ok(c.patch(f'/api/jobs/{ident}/geometry-review',json={'source_mesh_sha256':inv['source_mesh_sha256'],'island_ids':[target],'orientation':orientation,'review_note':'Repeat previously visually identified Surface3 can; API automation only, new-SHA visual inspection remains separate','acknowledge_geometry':True,'expected_input_revision':j['input_revision']}))
 context=j['geometry_review']['geometry_context_sha256']
 sizing={'mode':'uniform','reviewed_orientation':orientation,'reference':{'axis':'z','length':131.0,'unit':'mm','source':'estimated','correspondence':'full_mesh_extent','description':'Prior reviewed estimated full Z extent including lid/rim and base; not physical measurement'}}
 preview=ok(c.post(f'/api/jobs/{ident}/sizing-preview',json={'sizing':sizing,'orientation':orientation,'geometry_context_sha256':context}))
 props={'dimensions_m':preview['dimensions_m'],'mass_kg':{'value':0.30,'source':'estimated','note':'Prior diagnostic can estimated mass, not physical measurement'},'sliding_friction':None,'sizing':sizing,'geometry_context_sha256':context}
 j=ok(c.patch(f'/api/jobs/{ident}/properties',json=props))
 save(f'{ident}-reviewed-saved',j)
 return j

try:
 original_hash=digest(ARCHIVE.read_bytes())
 settings=server.acceptance_settings(DATA,'')
 raw=import_can(settings,ARCHIVE)
 historic=import_can(settings,ARCHIVE,historical_state=True)
 ident=str(raw.id); hid=str(historic.id)
 results['jobs']={'raw':ident,'historical':hid}
 # Historical F3 gate plus exact immutable ZIP continuity through correction.
 app=server.build_app(DATA,'')
 with TestClient(app) as c:
  before=ok(c.get(f'/api/jobs/{hid}'));save('O04-before',before)
  old_path=before['bundle_path']; old=c.get(f'/api/jobs/{hid}/files/{old_path}').content
  (ROOT/'O04-historical-bad-export.zip').write_bytes(old)
  gate=c.post(f'/api/jobs/{hid}/process'); assert gate.status_code==409; save('O04-initial-gate',{'status':gate.status_code,'body':gate.json()})
  changed=ok(c.patch(f'/api/jobs/{hid}/orientation',json={'x_deg':90.0,'y_deg':0.0,'z_deg':0.0}))
  assert changed['bundle_path'] is None
  gate=c.post(f'/api/jobs/{hid}/process');assert gate.status_code==409;save('O04-correction-gate',{'status':gate.status_code,'body':gate.json()})
  reviewed=review_can(c,hid)
  assert c.get(f'/api/jobs/{hid}/files/{old_path}').content==old
  assert historic.provider_task_id is None
  results['checks']['O04']={'api':'PASS','historical_export_sha256':digest(old),'initial_and_unreviewed_correction_gate':409,'legacy_extreme_dimensions':before['properties']['dimensions_m'],'corrected_dimensions':reviewed['properties']['dimensions_m'],'old_export_unchanged':True,'manual_visual':'PENDING parent'}
  review_can(c,ident)
 # Replay each Gemini case with real pinned can uploads, saved properties and seeded cache.
 for scenario in ('positive','unknown','malformed','truncated','quota','overload'):
  cache=server.seed_suggestions(settings,raw.id,replace=True)
  prior_cache=cache.read_bytes()
  app=server.build_app(DATA,'',gemini_replay=scenario)
  with TestClient(app) as c:
   before=ok(c.get(f'/api/jobs/{ident}'))
   cached=ok(c.get(f'/api/jobs/{ident}/suggestions'))
   response=c.post(f'/api/jobs/{ident}/suggestions',json={'refresh':True})
   body=response.json(); after=ok(c.get(f'/api/jobs/{ident}'))
   assert before==after
   if scenario in ('positive','unknown'):
    assert response.status_code==200
    if scenario=='positive':assert body['mass_kg']['value']==.08
    else:assert body['mass_kg'] is None and body['dimensions_m'] is None
   else:
    assert response.status_code==503 and body['manual_entry_available'] is True
    assert body['category']==('malformed' if scenario in ('malformed','truncated') else scenario)
    assert cache.read_bytes()==prior_cache
    assert ok(c.get(f'/api/jobs/{ident}/suggestions'))==cached
   assert len(app.state.ui_acceptance['replay'].events)==1
   save('P05-'+scenario,{'status':response.status_code,'response':body,'saved_job_unchanged':before==after,'cached_before':cached,'cache_retained':cache.read_bytes()==prior_cache,'saved_properties':after['properties'],'events':app.state.ui_acceptance['replay'].events})
 results['checks']['P05']={'api':'PASS','scenarios':['positive','unknown','malformed','truncated','quota','overload'],'saved_properties_retained':True,'manual_drafts':'API does not observe browser drafts; parent UI checks required'}
 # Two real-can jobs, one-shot processing failure then real retry in same lifespan.
 for stage in ('preparation','validation'):
  job=raw if stage=='validation' else import_can(settings,ARCHIVE)
  jid=str(job.id)
  app=server.build_app(DATA,'',fail_processing_job=job.id,fail_processing_stage=stage)
  with TestClient(app) as c:
   if stage=='preparation':review_can(c,jid)
   original=ok(c.get(f'/api/jobs/{jid}'))
   source=JobStore(DATA).job_dir(job.id)/original['mesh_path']; source_hash=digest(source.read_bytes())
   ok(c.post(f'/api/jobs/{jid}/process'),202)
   failed=terminal(c,jid,{'failed','completed'});save('R03-'+stage+'-failed',failed)
   assert failed['status']=='failed' and failed['error']['code']==stage+'_failed' and failed['bundle_path'] is None
   assert failed['attempts'][-1]['inputs_path']
   if stage=='validation':
    report=ok(c.get(f"/api/jobs/{jid}/files/{failed['validation_path']}"));save('R03-injected-validation-report',report)
    assert not report['passed'] and report['offline_acceptance_fixture']
   ok(c.post(f'/api/jobs/{jid}/process'),202)
   done=terminal(c,jid,{'failed','completed'});save('R03-'+stage+'-retried',done)
   assert done['status']=='completed',done
   assert len(done['attempts'])==2 and done['attempts'][0]==failed['attempts'][0]
   assert digest(source.read_bytes())==source_hash
   report=ok(c.get(f"/api/jobs/{jid}/files/{done['validation_path']}"));save('R03-'+stage+'-real-report',report)
   assert report['passed'] and report['portability_passed']
   export=c.get(f"/api/jobs/{jid}/files/{done['bundle_path']}");assert export.status_code==200
   (ROOT/f'R03-{stage}-retry.zip').write_bytes(export.content)
   results['checks']['R03-'+stage]={'api':'PASS','job_id':jid,'failed_attempt':failed['attempts'][0]['id'],'retry_attempt':done['attempts'][1]['id'],'bundle_sha256':digest(export.content),'real_validation':True,'source_unchanged':True}
   if stage=='validation':
    relocated=ROOT/'relocated-final-can';relocated.mkdir()
    with zipfile.ZipFile(io.BytesIO(export.content)) as z:z.extractall(relocated)
    model=mujoco.MjModel.from_xml_path(str(relocated/'scene.xml'));data=mujoco.MjData(model)
    steps=int(np.ceil(3/model.opt.timestep))
    for _ in range(steps):mujoco.mj_step(model,data)
    warnings=[int(v.number) for v in data.warning]
    assert np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all() and not any(warnings)
    mesh=trimesh.load_mesh(relocated/'meshes/visual.obj',process=False)
    expected=done['properties']['dimensions_m'];extents=[expected[k] for k in ('x','y','z')]
    assert np.allclose(mesh.extents,extents,atol=1e-7,rtol=0)
    save('relocation',{'sha':SHA,'mujoco':mujoco.__version__,'sim_time':data.time,'steps':steps,'finite':True,'warnings':warnings,'export_extent_m':mesh.extents.tolist(),'expected_extent_m':extents,'maximum_extent_error_m':float(np.max(np.abs(mesh.extents-extents))),'scene':str(relocated/'scene.xml'),'physical_or_viewer_acceptance':False})
 # Existing original fixture photos through actual worker, synthetic failure only.
 app=server.build_app(DATA,'',fail_next_reconstruction=True)
 source_root=JobStore(DATA).job_dir(raw.id)
 with TestClient(app) as c:
  def upload():
   files=[('images',(Path(p).name,(source_root/p).read_bytes(),'image/jpeg')) for p in raw.source_images]
   return ok(c.post('/api/jobs',files=files),202)['id']
  fid=upload(); failed=terminal(c,fid,{'failed','awaiting_properties'});save('R04-failed',failed)
  assert failed['status']=='failed' and failed['error']['code']=='provider_failed'
  for p in failed['source_images']:assert c.get(f'/api/jobs/{fid}/files/{p}').content==(source_root/p).read_bytes()
  later=upload(); recovered=terminal(c,later,{'failed','awaiting_properties'});save('R04-next-upload',recovered)
  assert recovered['status']=='awaiting_properties'
  assert ok(c.get(f'/api/jobs/{fid}'))==failed
  results['checks']['R04']={'api':'PASS','failed_job':fid,'subsequent_job':later,'uploads_retained_byte_identical':True,'failed_record_unchanged':True,'subsequent_mesh':'ordinary synthetic mock cube, not can quality acceptance'}
 assert digest(ARCHIVE.read_bytes())==original_hash
 results['original_archive_unchanged_sha256']=original_hash
 results['blocked_network_ledger_exists']=(DATA.parent/'blocked-network.jsonl').exists()
 results['status']='PASS_API_SCOPE'
except Exception:
 results['status']='ERROR';results['traceback']=traceback.format_exc();print(results['traceback'],flush=True)
finally:
 save('summary',results)
 print(json.dumps(results,indent=2),flush=True)
