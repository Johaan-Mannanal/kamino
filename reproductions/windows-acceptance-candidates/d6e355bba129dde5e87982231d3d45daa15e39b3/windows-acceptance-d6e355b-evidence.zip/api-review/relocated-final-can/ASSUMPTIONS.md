# Assumptions and provenance

Synthetic: False

Source labels describe the supplied evidence; review does not turn estimates into measurements.

- Collision: centred axis-aligned box; full property extents divided by two.
- Inertia: uniform solid cuboid approximation; not measured inertia.
- Gravity (m/s²): [0, 0, -9.81]; timestep (s): 0.0001.
- Contact solref: [0.002, 1] (numerical assumption).
- Initial object bottom height: 0.02 m.

| Item | Value | Source | Note |
| --- | --- | --- | --- |
| object mass (kg) | 0.3 | estimated | Prior diagnostic can estimated mass, not physical measurement |
| object sliding friction | unknown; simulator uses 0.8 | simulation default | not measured |
| Dimensions (m) | [0.02979368293108149, 0.029806611520258652, 0.131] | estimated | Derived mesh extents from uniform sizing; reference 131 mm on full Z extent (estimated). Prior reviewed estimated full Z extent including lid/rim and base; not physical measurement. Other dimensions are not independent measurements. |

Torsional/rolling friction, contact settings and box inertia are simulation assumptions.
Read the full JSON records for frames, limits, notes and retained provenance.

No measured physical accuracy or calibrated hardware response is established.
