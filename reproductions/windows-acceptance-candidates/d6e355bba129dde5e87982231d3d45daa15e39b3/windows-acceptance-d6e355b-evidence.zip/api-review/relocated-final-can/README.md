# Kamino portable MuJoCo export

This folder runs without the Kamino repository. Keep `scene.xml` and its mesh
folders together. All scene lengths are metres, angles radians, masses kilograms.

## Install in a separate environment

Use a Python version compatible with the recorded MuJoCo wheel. See
`environment.json` for the exporting environment; it is an observation, not a
cross-platform lockfile. `requirements.txt` pins the exported MuJoCo version.
If a wheel is unavailable for your OS/Python, choose a supported Python version
or explicitly record and revalidate any simulator version change.

macOS/Linux:
```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python run_simulation.py --headless --seconds 3
```

Windows PowerShell:
```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_simulation.py --headless --seconds 3
```

## View the scene

On Windows/Linux: `python run_simulation.py` (use the environment's interpreter).
On macOS: `mjpython run_simulation.py` (MuJoCo's GUI launcher in the same environment).
Add `--collision` to inspect collision geometry, or `--both` for both layers.
The MuJoCo viewer's Controls panel can adjust any exported position actuators.
Close the viewer to stop; rerunning starts from the saved initial state.

The runner resolves `scene.xml` beside itself, even from another working directory.
It starts with zero control targets. The headless mode only checks finite state
and simulator warnings; it does not repeat Kamino's tracking/contact/relocation
validation. It does not issue hardware commands.

## Interpret the result

- `ASSUMPTIONS.md`: readable property provenance and simulation approximations.
- `asset.json` (rigid) or `assembly.json` (articulated): editable source record.
- `simulation.json`: applied collision, inertia, contact and placement assumptions.
- `validation.json` (assembly) or `validation-report.json` (rigid), when present:
  saved pipeline validation evidence. Check its
  `passed` field and scope; creating an export alone does not establish a pass.
- Additional `prepared/`, `sources/` and `originals/` folders, when present, retain
  input/review history. They are not required by the standalone scene runner.

Record edits as a new experiment. Changing metadata JSON alone does not regenerate
`scene.xml`; re-export through Kamino or deliberately edit the simulator scene.
Existing reports apply only to the original exported files. Simulation acceptance
is not measured physical accuracy, hardware calibration or successful sim-to-real.
