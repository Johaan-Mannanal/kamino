"""Run the adjacent scene.xml with MuJoCo; no Kamino installation needed."""
import argparse
import json
import math
from pathlib import Path
import time

import mujoco
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--seconds", type=float, default=3.0)
    parser.add_argument("--collision", action="store_true", help="Show collision geoms instead of visual meshes")
    parser.add_argument("--both", action="store_true", help="Show visual and collision geoms together")
    args = parser.parse_args()
    if not math.isfinite(args.seconds) or not 0 < args.seconds <= 60:
        parser.error("--seconds must be finite, greater than zero, and at most 60")
    model = mujoco.MjModel.from_xml_path(str(Path(__file__).resolve().parent / "scene.xml"))
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    if args.headless:
        finite = True
        for _ in range(math.ceil(args.seconds / model.opt.timestep)):
            mujoco.mj_step(model, data)
            finite = bool(np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all() and np.isfinite(data.qacc).all())
            if not finite:
                break
        warning_count = sum(int(w.number) for w in data.warning)
        print(json.dumps({
            "scope": "standalone zero-control smoke check; not full validation",
            "mujoco": mujoco.__version__, "finite_state": finite,
            "simulated_time_s": float(data.time), "warning_count": warning_count,
        }, allow_nan=False))
        return 0 if finite and warning_count == 0 else 1
    from mujoco import viewer as native_viewer
    with native_viewer.launch_passive(model, data) as viewer:
        viewer.opt.geomgroup[2] = int(not args.collision or args.both)
        viewer.opt.geomgroup[3] = int(args.collision or args.both)
        viewer.opt.flags[mujoco.mjtVisFlag.mjVIS_CONVEXHULL] = int(args.collision or args.both)
        while viewer.is_running():
            start = time.perf_counter()
            mujoco.mj_step(model, data)
            viewer.sync()
            time.sleep(max(0, model.opt.timestep - (time.perf_counter() - start)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
