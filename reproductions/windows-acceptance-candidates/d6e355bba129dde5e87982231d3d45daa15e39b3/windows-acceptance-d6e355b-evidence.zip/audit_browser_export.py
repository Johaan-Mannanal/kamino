"""Read-only artifact audit; writes only fresh candidate relocation evidence."""
import hashlib
import json
import math
from pathlib import Path, PurePosixPath, PureWindowsPath
import stat
import xml.etree.ElementTree as ET
import zipfile

import mujoco
import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parent
SHA = "d6e355bba129dde5e87982231d3d45daa15e39b3"
archive = ROOT / "browser-retry.zip"
relocated = ROOT / "browser-relocated"
job = json.loads((ROOT / "D03-before-job.json").read_text(encoding="utf-8-sig"))
assert job["status"] == "completed" and job["input_revision"] == 5
assert job["properties"]["sizing"]["mode"] == "uniform"


def safe_relative(text):
    win = PureWindowsPath(text)
    posix = PurePosixPath(text.replace("\\", "/"))
    assert not win.drive and not win.is_absolute() and not posix.is_absolute(), text
    assert ".." not in posix.parts and ":" not in text, text
    return Path(*posix.parts)


assert not relocated.exists(), "Never overwrite relocation evidence"
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    names = bundle.namelist()
    assert len(names) == len(set(names)), "Duplicate archive members"
    for info in bundle.infolist():
        safe_relative(info.filename)
        assert not stat.S_ISLNK(info.external_attr >> 16), info.filename
    relocated.mkdir()
    for info in bundle.infolist():
        destination = relocated / safe_relative(info.filename)
        assert destination.resolve().is_relative_to(relocated.resolve())
        if info.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(bundle.read(info))

references = []
for xml_path in relocated.rglob("*.xml"):
    document = ET.parse(xml_path).getroot()
    compiler = document.find("compiler")
    dirs = {}
    if compiler is not None:
        for key in ("assetdir", "meshdir", "texturedir"):
            if compiler.get(key):
                dirs[key] = safe_relative(compiler.get(key))
    for element in document.iter():
        if not element.get("file"):
            continue
        name = safe_relative(element.get("file"))
        base = xml_path.parent
        if element.tag == "mesh":
            base /= dirs.get("meshdir", dirs.get("assetdir", Path()))
        elif element.tag == "texture":
            base /= dirs.get("texturedir", dirs.get("assetdir", Path()))
        target = (base / name).resolve()
        assert target.is_relative_to(relocated.resolve()), str(target)
        assert target.is_file(), str(target)
        references.append({"xml": xml_path.relative_to(relocated).as_posix(),
                           "tag": element.tag, "file": element.get("file"),
                           "resolved_relative": target.relative_to(relocated).as_posix(),
                           "exists": True})

scene = relocated / "scene.xml"
model = mujoco.MjModel.from_xml_path(str(scene))
data = mujoco.MjData(model)
steps = math.ceil(3 / model.opt.timestep)
for _ in range(steps):
    mujoco.mj_step(model, data)
warnings = [int(item.number) for item in data.warning]
finite = all(np.isfinite(array).all() for array in (data.qpos, data.qvel, data.qacc))
assert finite and not any(warnings)
mesh_path = relocated / "meshes" / "visual.obj"
mesh = trimesh.load_mesh(mesh_path, process=False)
expected = np.array([job["properties"]["dimensions_m"][axis] for axis in ("x", "y", "z")])
error = float(np.max(np.abs(mesh.extents - expected)))
assert error <= 1e-7
result = {
    "sha": SHA, "artifact": "browser-retry.zip",
    "zip_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "zip_bytes": archive.stat().st_size, "zip_crc_passed": True,
    "all_archive_paths_safe_relative": True, "xml_references": references,
    "all_xml_references_relative_existing_within_relocation": True,
    "job_id": job["id"], "input_revision": job["input_revision"],
    "active_attempt_id": job["active_attempt_id"],
    "mujoco": mujoco.__version__, "steps": steps, "sim_time": data.time,
    "finite": bool(finite), "warnings": warnings,
    "export_extent_m": mesh.extents.tolist(), "expected_extent_m": expected.tolist(),
    "maximum_extent_error_m": error, "tolerance_m": 1e-7,
    "visual_obj_sha256": hashlib.sha256(mesh_path.read_bytes()).hexdigest(),
    "scene": str(scene), "status": "PASS_NUMERICAL_RELOCATION_ONLY",
    "native_visual_or_physical_acceptance": False,
}
(ROOT / "browser-relocation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
