# Claude review invocation

Exact candidate: d6e355bba129dde5e87982231d3d45daa15e39b3
Base: a834763920176f34cafd07a49aa5ea9064bdc545

Invocation (cwd is this isolated review directory):

```powershell
Get-Content prompt.txt -Raw | claude -p --safe-mode --restricted --tools '' --strict-mcp-config --mcp-config mcp-empty.json --no-session-persistence --output-format json --effort high 1> result.json 2> stderr.txt
```

Only candidate.diff was included in the prompt. The ten changed tracked code files were copied locally and hashed for traceability. No original acceptance evidence, credentials, .env, logs, or user documents were sent. Tool access disabled, MCP empty, settings/customizations disabled through safe/restricted modes. No application source edits or browser controls were requested. User expressly authorized Claude Code delegation in the current conversation. This external code review is separate from application provider testing.
