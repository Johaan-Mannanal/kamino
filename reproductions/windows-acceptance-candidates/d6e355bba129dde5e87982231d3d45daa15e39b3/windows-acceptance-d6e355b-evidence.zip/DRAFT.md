Superseded by REPORT.md. This provisional draft is not the final result.
