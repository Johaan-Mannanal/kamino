import hashlib,json,zipfile
from pathlib import Path
r=Path(__file__).resolve().parent
sha=r.name
(r/'DRAFT.md').write_text('Superseded by REPORT.md. This provisional draft is not the final result.\n')
summary={'sha':sha,'disposition':'FOCUSED_ACCEPTANCE_PASS','full_release_acceptance':False,'tests':{'backend_focused_passed':111,'workspace_passed':119,'legacy_frontend_passed':103,'both_typechecks_and_builds':'PASS'},'focused_checks':{k:'PASS in REPORT.md scope' for k in ['saved_caption','O04','P05','R03','R04','S02','O01','Z03','D03']},'original_files_verified_unchanged':12086,'real_application_provider_calls':0,'claude_review':'Completed with explicit scoped disclosure approval; no confirmed acceptance-blocking defect','limitations':['Full backend suite and full checklist not rerun','Original native backend failures not waived','Physical/contact/grasp accuracy unverified'],'ui_export_sha256':'bbf9172e1b497ac7f48bec9292076b05a96f8edda6129ac1de516e3d96e93bc0','manual_evidence':'Corrected native screenshots independently reviewed; invalid provisional frames retained in capture-errors'}
(r/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for p in sorted(r.rglob('*')):
    if p.is_file() and p.name!='MANIFEST.json':
        b=p.read_bytes();files.append({'path':p.relative_to(r).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(r/'MANIFEST.json').write_text(json.dumps({'sha':sha,'files':files},indent=2)+'\n')
z=r.parent/'windows-acceptance-d6e355b-evidence.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
    for p in sorted(r.rglob('*')):
        if p.is_file():bundle.write(p,p.relative_to(r).as_posix())
with zipfile.ZipFile(z) as bundle:
    assert bundle.testzip() is None
    for item in files:assert hashlib.sha256(bundle.read(item['path'])).hexdigest()==item['sha256']
h=hashlib.sha256(z.read_bytes()).hexdigest()
z.with_suffix('.zip.sha256').write_text(h+'  '+z.name+'\n')
print(json.dumps({'archive':str(z),'sha256':h,'bytes':z.stat().st_size,'payloads':len(files),'report_exists':(r/'REPORT.md').exists()}))
