# Can investigation reproduction package

This archive preserves the **original incorrect export** independently of the current job, which now points to a manually corrected derivative. No new Meshy generation, photo capture, repair, server restart or provider request was performed while packaging.

## Contents

- `original/uploads/`: all three original JPEG uploads, byte-for-byte, retaining original EXIF metadata.
- `original/reconstruction/mesh.glb`: untouched Meshy result; four disconnected components including three can-like objects.
- `original/job-before-repair.json`, `properties.json`, `orientation-and-inputs.json`: original pointer, confirmed estimated values, phone orientations, and original preparation notes.
- `original/attempt/`: complete original attempt `eeb467cd-0965-4899-86e6-80d3388133b1`, including its original ZIP, report, prepared mesh, simulation input, and exported scene. **This is the failure to reproduce.**
- `manual/`: corrected derivative, repair log, current job record, and complete corrected attempt `8bd2fc4a-07f6-4740-8791-bc64ea8e02e3`. This is a human-assisted specimen-specific workaround, not a software fix.
- `report/`: error report and diagnostic before/after images, with working relative image links.
- `diagnostics/`: thumbnail evidence showing stored (non-transposed) photo orientation; originals above are authoritative.
- `investigation-scripts/`: exact retained investigation helpers. They assume the original laptop/project layout; **do not run `repair_can.py` or the store-changing helpers to reproduce the original failure**.
- `source/current/`: self-contained packaging-time working source, excluding env files, installed dependencies, ignored runtime data and Git metadata.
- `source/base-head-without-env.zip`: committed HEAD snapshot, with all env files/templates deliberately omitted.
- `source/identity.json`: HEAD and tree IDs, frontend import ref, SHA-256 identities of the dirty patches, source files and snapshot. No commit or stash was created.
- `source/dirty-tracked.patch`: aggregate tracked changes versus HEAD. `staged.patch` and `unstaged.patch` preserve the two layers; untracked source bytes and hashes are in `source/current/` and `current-files.json`.
- `environment/`: installed runtime versions and nonsecret model/provider settings. No credentials or env files are included.
- `MANIFEST.json` and `SHA256SUMS`: every payload file's SHA-256 and size. `SHA256SUMS` also covers `MANIFEST.json`; the checksum file does not hash itself. The ZIP's own SHA-256 is supplied as an adjacent download.

## Verify before use

From the extracted archive directory:

```powershell
python verify_package.py
```

This performs local file-integrity checks and makes no network calls.

## View the preserved original failure

With Python 3.12 and the recorded MuJoCo dependencies installed, run from the extracted archive directory:

```powershell
python source/current/tools/simulation/view.py --scene original/attempt/bundle/scene.xml
```

The original ZIP can alternatively be extracted into a separate new directory. Its contents are self-contained. Do not use the current live API job pointer to locate the original export.

To view the manual workaround instead:

```powershell
python source/current/tools/simulation/view.py --scene manual/attempt/bundle/scene.xml
```

## Re-run the original preparation/export locally

```powershell
python reproduce_original.py --output reproduced-original
```

The script loads the archived raw GLB and **pre-repair** properties through the archived working source. It writes only a fresh output directory, refuses to overwrite one, and never contacts Meshy or touches the live database. It reproduces the original all-components/unrotated/per-axis-scaling preparation and writes a new physics report; UUIDs and timing values will differ. It does not run any manual selection or orientation correction. Dependencies must already be installed; use the recorded runtime manifest and project dependency definitions to prepare an environment separately if needed.

## What happened

The raw reconstruction contains multiple objects. The application treated all components as one asset, did not align native +Y can height with simulation +Z, and independently scaled the whole scene to 57 × 57 × 131 mm. This produced approximately 951.2% scale-factor spread. Its box-proxy physics test passed but did not validate whether the geometry resembled the requested can. All three originals have EXIF orientation 6; local normalization was absent, but its causal contribution was not isolated. The original request was geometry-only, so branding/label textures are absent by design.

The manual correction isolated the central can, rotated it, and fitted the saved dimensions. Its raw GLB and original attempt remain unchanged. The software does not yet perform that selection/review workflow automatically.

## Identity and privacy limits

The source snapshot is exact at **packaging time** subject to the listed env-file omissions. There was no separately archived dirty-patch snapshot at the instant of the original failure, so this package does not invent one. The pre-repair record, original uploads, raw mesh, original ZIP, and original report are preserved bytes and explicitly hashed. The actual uploaded JPEGs retain their original metadata and background scene because they were requested for reproduction; treat this package as private. Credentials, `.env` files and `.env` templates are excluded, including from nested ZIP snapshots. Known configured secret values were checked against all archived payloads. Test-fixture strings such as `test-secret` in source tests are dummy values, not configured credentials.
