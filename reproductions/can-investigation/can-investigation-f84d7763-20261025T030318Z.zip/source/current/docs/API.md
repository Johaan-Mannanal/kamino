# Shared contract v1

Authoritative Python models: `src/photo2sim/contracts.py`. Backend owns this file; propose coordinated changes rather than creating parallel schemas. A synthetic response fixture is at `examples/api/job-awaiting-properties.json`; its paths/ID are illustrative, not a live job.

## HTTP interface

- `GET /api/health`: service status and configured reconstruction provider.
- `POST /api/jobs`: multipart field **`images`**, repeated for 1–4 JPEG/PNG/WebP images, at most 10 MiB and 25 megapixels each. Returns **202** and `JobRecord`.
- `GET /api/jobs/{id}`: returns `JobRecord`; poll while reconstruction runs.
- `PATCH /api/jobs/{id}/properties`: JSON `AssetProperties`; accepted at `awaiting_properties` or after a simulation-stage failure. Saving corrected properties returns to `awaiting_properties` and clears current result pointers while retaining prior attempt files. Saves confirmed inputs. Processing starts with a separate explicit request.
- `POST /api/jobs/{id}/process`: no body. Requires a reconstructed mesh and saved properties. Returns **202** with status `preparing`, then runs preparation, export and headless validation asynchronously. Duplicate/running/completed requests return **409**. Failed simulation attempts can be retried with this endpoint; existing attempt files are retained. Reconstruction failures require separate diagnosis, not this retry.
- `GET /api/jobs/{id}/files/{path}`: job-relative artifact download, e.g. `reconstruction/mesh.glb` or `uploads/00.png`.
- `/docs` and `/openapi.json`: generated API documentation once the backend starts.

Phone JPEGs identified as MPO are accepted as JPEG uploads with their original bytes preserved. A provenance-labeled property example for the first real object is at `examples/api/apple-20w-estimated-properties.json`; these are reference-based estimates, not measurements.

State sequence: `queued → reconstructing → awaiting_properties → preparing → validating → completed`; failures use `failed` and `{code, message}`. Completion requires passing original and relocated scene validation and successful ZIP packaging. `progress` describes reconstruction, not total pipeline completion. A 100% reconstruction job can still await properties.

The provider is configured server-side (`mock` by default). Never accept API keys or arbitrary provider download URLs from the browser. Mock jobs have `synthetic: true`; they produce a known cube and make no claim of photo reconstruction. CORS for local frontend development permits `http://localhost:5173` and `http://127.0.0.1:5173`.

`JobRecord` contains `schema_version`, `id`, `status`, `provider`, `synthetic`, timestamps, `progress`, `source_images`, `provider_task_id`, `mesh_path`, `properties`, `asset`, `export_path`, `validation_path`, `bundle_path`, and `error`. Nullable fields are initially null. Top-level paths in responses are relative to that job's artifact directory, never Windows/Mac absolute paths. Missing jobs/files return 404, invalid properties return 422, and wrong-stage updates return 409.

After processing, `export_path` names `attempts/{attempt}/bundle/scene.xml`, `validation_path` names its `validation-report.json`, and `bundle_path` names `attempts/{attempt}/simulation.zip`. Download each using `/api/jobs/{id}/files/{path}`. The ZIP contains `scene.xml` at its root with relative meshes, `asset.json`, `simulation.json` and the actual validation report. Failed validation can expose its diagnostic scene/report but never sets `bundle_path`. Only show a successful download action for `status == completed` and non-null `bundle_path`.

`asset.visual_mesh` is **bundle-relative**, unlike top-level job paths. Once `export_path` exists, its visual mesh's job-relative path is `dirname(export_path) + '/' + asset.visual_mesh`. Reconstruction preview still uses `mesh_path`. Early preparation failures may have `asset` set without an export; do not infer a downloadable mesh from `asset` alone.

Restarting while preparing/validating marks the job `failed` with `processing_interrupted`; retry `/process` to use the cached reconstruction in a new attempt. This never submits another paid generation. Processing errors are sanitized and retain saved artifacts. Unexpected validator exceptions still produce a safe failure report. A failed simulation can be retried directly or have its properties corrected with PATCH first; reconstruction failures cannot use this recovery path. Without the simulation extra, processing fails with `simulation_unavailable` and installation instructions.

Provider status polling and asset downloads retry transient connection failures and HTTP 408, 429, 500, 502, 503, or 504 responses up to three total attempts, waiting one then two seconds. Shutdown interrupts those waits and leaves the saved task resumable at startup. Invalid responses, terminal HTTP errors, invalid meshes, and local file errors fail immediately. Paid generation submission is never automatically retried. Exhausted read retries retain the task ID for diagnosis.

## Property input

```json
{
  "dimensions_m": {"x": 0.04, "y": 0.05, "z": 0.06, "source": "measured"},
  "mass_kg": {"value": 0.08, "source": "user_supplied"},
  "sliding_friction": null
}
```

Dimensions are **full extents**, in metres, after mesh orientation. Mass is in kilograms. Dimensions/mass must be positive and finite. Sliding friction is a nonnegative finite coefficient for the contacting surface pair; null means unknown. Source values: `measured`, `user_supplied`, `sourced`, `estimated`. Each property record permits a `note`. AI suggestions remain `estimated` until an operator supplies/records evidence.

## Geometry boundary — Srijan

Implemented in `src/photo2sim/assets/prepare.py`:

```python
def prepare_asset(
    mesh_path: Path, output_dir: Path, properties: AssetProperties
) -> AssetRecord: ...
```

Input is a local reconstructed OBJ or GLB. The implementation preserves input axes and documents that they must match the supplied x/y/z extents; it does not infer upright orientation or automatically convert glTF +Y-up to MuJoCo +Z-up. It centres the bounding box, independently scales each axis to the supplied full extents, and warns about distortion. It returns a self-contained mesh, unchanged property provenance and box collision metadata. The orchestrator propagates `job.synthetic` and preserves textured preparation while supplying a separate geometry-only copy to the first simulation exporter. Source geometry is preserved; dimensions and mass are never inferred during preparation.

## Simulation boundary — Yash

Implemented in `src/photo2sim/simulation/export.py`:

```python
def export_asset(asset: AssetRecord, asset_dir: Path, output_dir: Path) -> Path: ...
```

Read relative mesh paths from `asset_dir`, build a portable scene bundle in `output_dir`, and return its `scene.xml` path. Use the confirmed properties. Keep simulation assumptions and actual validation results in metadata/report files. Do not edit the shared contracts without coordination. This interface follows the standalone Windows baseline; it does not replace that initial task.

## Frontend boundary — Atul

Own `frontend/`, independent of the Python backend directory. Use the HTTP interface above. Set API base URL via configuration. Multipart uploads must let the browser choose the boundary. Show synthetic/provider labels, preserve property provenance, and distinguish reconstruction progress from scene completion. Polling must stop on terminal/error/awaiting-input states. Preview/download controls appear only when the corresponding artifact exists. Build mocks using the same response shape while backend/preparation/export are being integrated. Fetch integration later calls this same API; it does not duplicate reconstruction or geometry logic.
