"""Apple 20W US two-blade USB-C charger reference model for the local demo.

This is a procedural replacement for the malformed reconstruction, not a repair
of the photographed specimen. Body dimensions and mass use published A2940
measurements; the plug extension and small details remain approximations.
"""

import json
import xml.etree.ElementTree as ET

import numpy as np
import trimesh


def rounded_box(extents, radius):
    """Create a closed convex surface with the requested full extents."""
    half = np.asarray(extents) / 2
    inner = half - radius
    vertices, faces = [], []
    # Project six subdivided cube faces onto a box with spherical corners.
    # This constructs the surface directly without an optional hull library.
    samples = [
        np.unique(np.round(np.r_[np.linspace(-h, h, 25), -i, i], 12)) for h, i in zip(half, inner)
    ]
    for axis in range(3):
        u, v = (axis + 1) % 3, (axis + 2) % 3
        for sign in (-1, 1):
            start = len(vertices)
            for a in samples[u]:
                for b in samples[v]:
                    point = np.zeros(3)
                    point[axis], point[u], point[v] = sign * half[axis], a, b
                    core = np.clip(point, -inner, inner)
                    normal = point - core
                    vertices.append(core + radius * normal / np.linalg.norm(normal))
            width = len(samples[v])
            for i in range(len(samples[u]) - 1):
                for j in range(width - 1):
                    a = start + i * width + j
                    triangles = [(a, a + width, a + width + 1), (a, a + width + 1, a + 1)]
                    faces.extend(triangles if sign == 1 else [t[::-1] for t in triangles])
    mesh = trimesh.Trimesh(vertices=vertices, faces=faces, process=True)
    if not mesh.is_watertight or not mesh.is_winding_consistent:
        raise ValueError("Rounded charger shell must be a closed, consistently wound mesh")
    return mesh


def add_charger(asset, body, output):
    meshes = output / "meshes"
    for name, dimensions, radius in (
        ("charger_shell", (0.0425, 0.027, 0.0415), 0.005),
        ("plug_face", (0.0315, 0.016, 0.0005), 0.0002),
        ("usb_rim", (0.010, 0.0045, 0.0008), 0.00035),
        ("usb_socket", (0.0088, 0.0033, 0.0009), 0.0004),
    ):
        mesh = rounded_box(dimensions, radius)
        mesh.export(meshes / (name + ".obj"))
        ET.SubElement(asset, "mesh", name=name, file=name + ".obj")

    ET.SubElement(
        body,
        "geom",
        name="charger_shell",
        type="mesh",
        mesh="charger_shell",
        pos="0 0 -0.008",
        rgba="0.94 0.94 0.92 1",
        group="2",
        friction="1 0.01 0.001",
        solref="0.008 1",
    )
    ET.SubElement(
        body,
        "geom",
        name="plug_face",
        type="mesh",
        mesh="plug_face",
        pos="0 0 0.01265",
        rgba="0.72 0.73 0.73 1",
        group="2",
        contype="0",
        conaffinity="0",
    )
    # Distinct blade contacts leave the space between the pins empty.
    for side, x in (("left", -0.00635), ("right", 0.00635)):
        ET.SubElement(
            body,
            "geom",
            name="charger_blade_" + side,
            type="box",
            pos=f"{x} 0 0.02075",
            size="0.00075 0.00315 0.008",
            rgba="0.64 0.67 0.7 1",
            group="2",
            friction="0.6 0.005 0.0001",
        )
    # Surface detail on the face opposite the plug; this is a visual socket.
    for name, z, color in (
        ("usb_rim", -0.02855, "0.55 0.58 0.6 1"),
        ("usb_socket", -0.02885, "0.025 0.03 0.035 1"),
    ):
        ET.SubElement(
            body,
            "geom",
            name=name,
            type="mesh",
            mesh=name,
            pos=f"0 0 {z}",
            rgba=color,
            group="2",
            contype="0",
            conaffinity="0",
        )
    ET.SubElement(
        body,
        "geom",
        name="usb_tongue",
        type="box",
        size="0.003 0.00035 0.0001",
        pos="0 0 -0.02935",
        rgba="0.24 0.25 0.27 1",
        group="2",
        contype="0",
        conaffinity="0",
    )
    record = {
        "model": "Apple 20W USB-C adapter, US two-blade reference approximation",
        "reference_url": "https://www.chargerlab.com/review-of-new-apple-20w-charger-for-iphone-15-a2940",
        "source": "synthetic; replaces malformed reconstruction only in the pickup demo",
        "dimensions_source": "ChargerLAB A2940 review: 41.5 x 42.5 x 27 mm shell; not specimen measurements",
        "shell_extents_m": [0.0425, 0.027, 0.0415],
        "overall_extents_m": [0.0425, 0.027, 0.0575],
        "pin_extension_m": 0.016,
        "pin_extension_source": "assumed, not included in published body dimensions",
        "mass_kg": 0.0585,
        "pin_spacing_source": "assumed US plug geometry; specimen plug variant unconfirmed",
        "collision": "rounded shell and two separate blade boxes",
        "usb_port": "surface detail, not a socket suitable for connector insertion",
        "grasp": "assisted weld, not a friction-grasp validation",
    }
    (output / "charger-model.json").write_text(json.dumps(record, indent=2) + "\n")
