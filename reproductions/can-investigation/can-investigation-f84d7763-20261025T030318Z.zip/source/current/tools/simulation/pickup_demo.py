"""SO-101 charger pickup demo. Assisted weld grasp, not friction-grasp validation."""

import argparse
import json
import shutil
import time
import xml.etree.ElementTree as ET
from pathlib import Path

import mujoco
import numpy as np
from charger_model import add_charger

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/simulation/arm-charger"


def build():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "meshes").mkdir(exist_ok=True)
    r = ET.parse(ROOT / "outputs/simulation/arm-view/scene.xml").getroot()
    r.set("model", "SO-101 charger pickup - assisted grasp demo")
    compiler = r.find("compiler")
    source = Path(compiler.get("meshdir"))
    compiler.set("meshdir", "meshes")
    for mesh in r.find("asset"):
        shutil.copy2(source / mesh.get("file"), OUT / "meshes" / mesh.get("file"))
    r.find("option").attrib.update(gravity="0 0 -9.81", timestep="0.002", integrator="implicitfast")
    r.find("statistic").attrib.update(center="0.15 0 0.16", extent="0.65")
    visual = ET.SubElement(r, "visual")
    ET.SubElement(
        visual, "headlight", ambient="0.4 0.4 0.4", diffuse="0.8 0.8 0.8", specular="0.2 0.2 0.2"
    )
    world = r.find("worldbody")
    # The supplied URDF repeats visual and collision meshes. Keep the visual set.
    for body in world.iter("body"):
        for g in list(body.findall("geom")):
            if g.get("group") != "1":
                body.remove(g)
        if body.find("joint") is not None:
            body.set("gravcomp", "1")
    for j in world.iter("joint"):
        j.set("damping", "0.6")
        j.set("armature", "0.015")
    gripper = world.find(".//body[@name='gripper_link']")
    ET.SubElement(
        gripper, "site", name="grasp", pos="-0.0079 0 -0.080", size="0.004", rgba="0 0 0 0"
    )
    # Contact with the floor remains physical; the grasp uses a documented weld.
    charger = ET.SubElement(world, "body", name="charger", pos="0.2 0 0.029")
    ET.SubElement(charger, "freejoint", name="charger_free")
    ET.SubElement(
        charger,
        "inertial",
        pos="0 0 -0.0075",
        mass="0.0585",
        diaginertia="0.000011949 0.000017198 0.000012355",
    )
    add_charger(r.find("asset"), charger, OUT)
    act = ET.SubElement(r, "actuator")
    for j in world.iter("joint"):
        ET.SubElement(
            act,
            "position",
            name=j.get("name") + "_servo",
            joint=j.get("name"),
            kp="160",
            kv="8",
            ctrllimited="true",
            ctrlrange=j.get("range"),
        )
    ET.SubElement(
        ET.SubElement(r, "equality"),
        "weld",
        name="assisted_grasp",
        body1="gripper_link",
        body2="charger",
        active="false",
        solref="0.008 1",
    )
    ET.indent(r)
    ET.ElementTree(r).write(OUT / "scene.xml", encoding="unicode")
    return mujoco.MjModel.from_xml_path(str(OUT / "scene.xml"))


def ik(m, target, seed, upright=True):
    d = mujoco.MjData(m)
    q = np.array(seed, dtype=float)
    sid = m.site("grasp").id
    jp, jr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
    for _ in range(350):
        d.qpos[:5] = q
        mujoco.mj_forward(m, d)
        z = d.site_xmat[sid].reshape(3, 3)[:, 2]
        e = np.r_[
            np.asarray(target) - d.site_xpos[sid],
            (0.12 if upright else 0) * (np.array([0.0, 0.0, 1.0]) - z),
        ]
        if np.linalg.norm(e) < 0.00005:
            break
        mujoco.mj_jacSite(m, d, jp, jr, sid)
        skew = np.array([[0, -z[2], z[1]], [z[2], 0, -z[0]], [-z[1], z[0], 0]])
        jac = np.vstack([jp[:, :5], -(0.12 if upright else 0) * skew @ jr[:, :5]])
        delta = jac.T @ np.linalg.solve(jac @ jac.T + np.eye(6) * 0.00002, e)
        q = np.clip(
            q + np.clip(delta, -0.12, 0.12), m.jnt_range[:5, 0] + 0.005, m.jnt_range[:5, 1] - 0.005
        )
    if np.linalg.norm(e[:3]) > 0.002:
        raise RuntimeError(f"IK failed for {target}: {e}")
    return q


def plan(m):
    pickup = ik(m, [0.2, 0, 0.029], [0.046, -0.167, 0.684, 1.054, -1.766])
    above = ik(m, [0.2, 0, 0.15], pickup, False)
    place = ik(m, [0.18, -0.12, 0.029], pickup)
    overplace = ik(m, [0.18, -0.12, 0.15], place, False)
    return [above, pickup, above, overplace, place, overplace]


class Demo:
    def __init__(self, m, goals):
        self.m = m
        self.d = mujoco.MjData(m)
        self.goals = goals
        self.sid = m.site("grasp").id
        self.bid = m.body("charger").id
        self.gid = m.body("gripper_link").id
        self.eid = m.equality("assisted_grasp").id
        self.attached = False
        self.max_height = 0.0
        self.min_distance = 1.0
        self.reset()

    def reset(self):
        mujoco.mj_resetData(self.m, self.d)
        self.d.qpos[:6] = np.r_[self.goals[0], 0.85]
        self.d.ctrl[:] = self.d.qpos[:6]
        self.d.eq_active[self.eid] = 0
        mujoco.mj_forward(self.m, self.d)
        self.attached = False

    def attach(self):
        d, m = self.d, self.m
        distance = np.linalg.norm(d.site_xpos[self.sid] - d.xpos[self.bid])
        self.min_distance = min(self.min_distance, float(distance))
        if distance > 0.012:
            raise RuntimeError(f"Grasp missed by {distance:.3f} m")
        rot = d.xmat[self.gid].reshape(3, 3)
        relpos = rot.T @ (d.xpos[self.bid] - d.xpos[self.gid])
        inverse = d.xquat[self.gid].copy()
        inverse[1:] *= -1
        relquat = np.zeros(4)
        mujoco.mju_mulQuat(relquat, inverse, d.xquat[self.bid])
        m.eq_data[self.eid, 3:6] = relpos
        m.eq_data[self.eid, 6:10] = relquat
        d.eq_active[self.eid] = 1
        self.attached = True

    def step(self):
        t = self.d.time
        g = self.goals
        # Each phase starts and ends at rest using cubic interpolation.
        phases = [
            (1.5, g[0], g[0], 0.85, 0.85),
            (2.8, g[0], g[1], 0.85, 0.85),
            (1.3, g[1], g[1], 0.85, 0.22),
            (2.8, g[1], g[2], 0.22, 0.22),
            (3.0, g[2], g[3], 0.22, 0.22),
            (2.8, g[3], g[4], 0.22, 0.22),
            (1.2, g[4], g[4], 0.22, 0.85),
            (2.5, g[4], g[5], 0.85, 0.85),
            (1.8, g[5], g[5], 0.85, 0.85),
        ]
        elapsed = 0
        for i, (dur, a, b, ga, gb) in enumerate(phases):
            if t < elapsed + dur:
                u = np.clip((t - elapsed) / dur, 0, 1)
                u = u * u * (3 - 2 * u)
                self.d.ctrl[:5] = (1 - u) * a + u * b
                self.d.ctrl[5] = (1 - u) * ga + u * gb
                if i >= 3 and i <= 5 and not self.attached:
                    self.attach()
                if i >= 6 and self.attached:
                    self.d.eq_active[self.eid] = 0
                    self.attached = False
                break
            elapsed += dur
        mujoco.mj_step(self.m, self.d)
        self.max_height = max(self.max_height, float(self.d.xpos[self.bid, 2]))
        if not np.isfinite(self.d.qpos).all():
            raise RuntimeError("Nonfinite state")
        return t < sum(p[0] for p in phases)


def main():
    args = argparse.ArgumentParser()
    args.add_argument("--headless", action="store_true")
    args = args.parse_args()
    m = build()
    goals = plan(m)
    demo = Demo(m, goals)
    if args.headless:
        while demo.step():
            pass
        result = {
            "assisted_grasp": True,
            "max_charger_height_m": demo.max_height,
            "grasp_distance_m": demo.min_distance,
            "final_position_m": demo.d.xpos[demo.bid].tolist(),
            "warnings": [int(w.number) for w in demo.d.warning],
        }
        if demo.max_height < 0.12:
            raise RuntimeError(f"Lift failed: {result}")
        if np.linalg.norm(demo.d.xpos[demo.bid, :2] - [0.18, -0.12]) > 0.025:
            raise RuntimeError(f"Placement failed: {result}")
        (OUT / "verification.json").write_text(json.dumps(result, indent=2))
        print(json.dumps(result), flush=True)
        renderer = mujoco.Renderer(m, height=480, width=640)
        cam = mujoco.MjvCamera()
        cam.lookat[:] = [0.16, 0, 0.12]
        cam.distance = 0.72
        cam.azimuth = 135
        cam.elevation = -25
        # Render the lifted state for a visual check.
        demo.reset()
        while demo.d.time < 10:
            demo.step()
        renderer.update_scene(demo.d, camera=cam)
        from PIL import Image

        Image.fromarray(renderer.render()).save(OUT / "pickup-preview.png")
        renderer.close()
    else:
        from mujoco import viewer as mj_viewer

        with mj_viewer.launch_passive(m, demo.d) as viewer:
            viewer.cam.lookat[:] = [0.16, 0, 0.12]
            viewer.cam.distance = 0.58
            viewer.cam.azimuth = 135
            viewer.cam.elevation = -25
            viewer.opt.geomgroup[3] = 0
            print("Arm + charger viewer running. Scripted pickup with assisted grasp.", flush=True)
            while viewer.is_running():
                start = time.perf_counter()
                for _ in range(8):
                    if not demo.step():
                        demo.reset()
                viewer.sync()
                time.sleep(max(0, 8 * m.opt.timestep - (time.perf_counter() - start)))


if __name__ == "__main__":
    main()
