"""Verified HTTPS clients, including Windows' installed certificate authorities."""

import ssl
import sys

import httpx


def provider_client(*, transport: httpx.BaseTransport | None = None) -> httpx.Client:
    # HTTPX's bundled CA list omits locally installed Windows corporate/proxy CAs.
    # The system context includes them while retaining hostname and chain checks.
    verify = ssl.create_default_context() if sys.platform == "win32" and transport is None else True
    return httpx.Client(timeout=60, transport=transport, verify=verify)
