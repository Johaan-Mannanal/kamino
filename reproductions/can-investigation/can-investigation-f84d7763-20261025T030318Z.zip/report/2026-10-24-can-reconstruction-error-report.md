# Can reconstruction and simulation error report

Date: 2026-10-24 (America/Los_Angeles)
Status: Reproducible product failure; one job manually corrected. General software correction is **not implemented**. Further work is on hold pending user instructions.

## User-visible failure

The user uploaded three photos of one beverage can, confirmed dimensions of 57 × 57 × 131 mm and mass of 260 g, and generated a simulation. The exported object did not resemble the intended upright can. The API marked the job `completed` because its box-proxy physics checks passed.

This is a software workflow failure. Manual repair of this particular job does not demonstrate that the application can reliably reconstruct and export a selected object by itself.

## Identification

- Application job: `f84d7763-8ede-40e5-8823-43da1239e7e6`.
- Meshy task: `01a170ef-46b9-749f-89d5-e4b1046c3e31`.
- Provider/model: Meshy, `meshy-6`, geometry-only request (`should_texture=false`, `auto_size=false`).
- Current working branch: `codex/fix-reconstruction-retries-and-scene-validation`.
- Base HEAD: `5f368cc5db3e9d53e8b5731b41fec5e0a3096d87`, with local changes present. This SHA alone does not reproduce the full current workspace.
- Frontend source imported locally from `codex/web-workflow` at `7e89262d6b3f6344620bf248eb1de1afb1f284e3`; not merged into remote `main`.
- Raw GLB SHA-256: `5b9ced8ce875c19b18abd171ce328959a443e6eb3103a21202f94280081bf6ec`.

## Evidence and confirmed causes

### 1. Object selection was not established

The photos contain the intended central can plus other cans, a bottle, laptop, table and other surroundings. Inspecting the cached raw GLB shows three disconnected can-like objects and a small fourth component. The application submitted the full photos without an explicit target selection, then concatenated all mesh geometry for preparation.

The largest component has 37,604 vertices and extents approximately `[0.415061, 1.824983, 0.415241]` in provider units. The smaller two cylinders each have roughly 10,900 vertices. The software did not ask the user which component was the target.

### 2. Orientation and whole-scene scaling severely distorted the export

The complete raw GLB has extents `[1.88946, 1.89923, 0.415241]`. The principal can length follows native **Y**, while the entered physical can height is **Z**.

`prepare_asset` explicitly assumes input axes already match the supplied property axes and does not rotate the asset. It independently scaled the entire multi-object scene to `[0.057, 0.057, 0.131]` metres. Its own notes record a scale-factor ratio of approximately `1.005 : 1.000 : 10.512` and **951.2% scale-factor spread**. This metric is the spread between scale factors, not a measured percentage error relative to the real can.

The warning was recorded as metadata, but preparation and export continued. Relative object positions, axis mismatch, and severe anisotropic scaling were all accepted.

![Raw Meshy output above; original exported geometry below](evidence/can-error-2026-10-24/raw-and-original-export.png)

### 3. Phone orientation metadata was not normalized before submission

All three saved JPEGs are 5712 × 4284 pixels and have EXIF orientation **6**. `MeshyProvider.submit` base64-encodes the original file bytes and does not transpose or resize them. The earlier successful charger handoff documented EXIF-normalized, resized JPEG copies.

The missing preprocessing is confirmed. Whether Meshy honored these photos' EXIF orientation, and how much it contributed to this result, has **not** been isolated. It should not be presented as the proven sole cause.

### 4. Numerical validation does not establish object fidelity

The validator checks an upright box proxy: finite state, falling, contact, penetration, resting height, settling, warnings and relocation. It does not verify object identity, a single selected target, orientation against photos, circularity, proportions against photos, or label appearance.

Passing this check cannot establish that the generated shape is the requested can. The job completion and download flow lacked a geometry review gate.

### 5. Label appearance was never requested

The Meshy call explicitly requested untextured geometry, and the simulation pipeline exports a geometry-only visual with a uniform blue material. Missing beverage branding is expected under those settings. This is separate from the incorrect shape and multiple-object failure.

## Reproduction using preserved local artifacts

Project root: `C:/Users/srija/calhacks-arm`.
Job directory: `artifacts/photo2sim/f84d7763-8ede-40e5-8823-43da1239e7e6/`.

1. Inspect `uploads/00.jpg`, `uploads/01.jpg`, and `uploads/02.jpg`, including EXIF orientation.
2. Load the untouched `reconstruction/mesh.glb`; verify its SHA-256 above and observe the disconnected objects.
3. Inspect the original failed-in-appearance export at `attempts/eeb467cd-0965-4899-86e6-80d3388133b1/bundle/scene.xml` and its `asset.json` notes. The associated ZIP and report remain in that attempt.
4. Compare the original scene to the source photos. Original physics validation passed despite the incorrect geometry.

The current job now points to the manually corrected derivative; rerunning its processing is **not** a reproduction of the original failure. Use the preserved original attempt or raw GLB for investigation.

## Manual intervention completed for this job

No new Meshy generation was submitted for this repair, and no additional reconstruction credits were used.

- Retained the raw GLB and the original export attempt.
- Selected the largest connected surface component after visually inspecting all components as this specimen's main can; removed three smaller components from the derivative.
- Applied a specimen-specific +90° rotation about X, mapping native +Y to simulation +Z.
- Fitted the isolated component to the user's saved estimated 57 × 57 × 131 mm dimensions. The source component was itself overly elongated, so this includes nonuniform height adjustment; it is not a measured shape reconstruction.
- Wrote `reconstruction/can-selected-upright.obj` and `reconstruction/can-repair.json`. The pre-repair job record is `reconstruction/job-before-can-repair.json`.
- Changed this job's `mesh_path` to the derivative and created a new processing attempt. The provider task ID and raw GLB remain retained.
- Current corrected scene: `attempts/8bd2fc4a-07f6-4740-8791-bc64ea8e02e3/bundle/scene.xml`.
- Current corrected ZIP: `attempts/8bd2fc4a-07f6-4740-8791-bc64ea8e02e3/simulation.zip`.
- Confirmed the corrected mesh is closed, finite, dimensionally matched, upright, and visually recognizable as one can in a rendered inspection.

![Manually corrected can; uniform simulation material](evidence/can-error-2026-10-24/manual-correction.png)

### Verification limits

The corrected original and relocated scenes each passed 30,000 steps / 3 simulated seconds. Maximum penetration was approximately 0.4515 mm, below the existing 1 mm threshold; all warning checks passed. Rendered full extents match 57 × 57 × 131 mm within numerical tolerance.

Collision remains a bounding box; inertia remains the current uniform-box approximation. Label textures are absent, and the saved dimensions and mass remain estimated. No physical robot pickup, manipulation success, or real-world dimensional accuracy has been established. The validator's `viewer_inspected=false` flag was not changed merely because a separate rendered inspection was performed.

## Software work proposed, not implemented

1. Normalize EXIF orientation and prepare consistently sized provider input copies while preserving originals. Add a regression test using a real EXIF-6 JPEG.
2. Establish the target object before reconstruction: user-selected crop/foreground or an explicit review step. Test photos with several objects rather than assuming a centered target.
3. Provide orientation review and an explicit rigid transformation before dimensions are applied. Do not infer a universal orientation from one can or blindly apply a Y/Z swap to every asset.
4. Detect disconnected components and require target confirmation. Selecting the largest component automatically is not a general solution.
5. Gate severe anisotropic distortion and explain which axes/proportions disagree. Decide an explicit policy and confirmation flow before changing the existing preparation contract.
6. Separate physics smoke-test success from geometry acceptance in the API/UI. Require a visual preview and meaningful confirmation before presenting an asset as ready.
7. Add end-to-end geometry regressions for an upright can, a rotated can, distractor objects and implausible scaling. Existing mocked provider and physics tests do not cover these failures.
8. Make geometry-only appearance and box collision approximations visible in the workflow; add texture support separately if required.

## Handoff and hold

The manual correction is a job-specific workaround. No general segmentation, orientation, image-preprocessing, distortion-gating, or geometry-acceptance fix was added during this investigation. Existing earlier HTTPS certificate fixes and frontend files remain in the working tree.

The report and two diagnostic images are local files ready to share. Source photos, credentials and large model artifacts are not embedded in this report. The referenced ignored `artifacts/` files require a separate transfer if another laptop needs to reproduce the investigation.

Further implementation, new paid reconstruction, branch merges, commits, pushes and deployment are on hold until the user provides instructions.
