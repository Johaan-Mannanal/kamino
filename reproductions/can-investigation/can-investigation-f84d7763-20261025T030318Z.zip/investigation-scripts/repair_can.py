from pathlib import Path
from uuid import UUID
import hashlib,json
import numpy as np,trimesh
from photo2sim.api.config import Settings
from photo2sim.api.store import JobStore
from photo2sim.contracts import AssetProperties
store=JobStore(Settings.from_env().data_dir);j=store.get(UUID('f84d7763-8ede-40e5-8823-43da1239e7e6'));root=store.job_dir(j.id)
(root/'reconstruction/job-before-can-repair.json').write_text(j.model_dump_json(indent=2))
raw=root/'reconstruction/mesh.glb';before=hashlib.sha256(raw.read_bytes()).hexdigest()
m=trimesh.load_mesh('outputs/system-check/can-largest-raw.obj',process=False)
original_extents=m.extents.copy()
# Reviewed specimen-specific alignment: native +Y is the cylinder axis.
rotation=np.array([[1.,0,0],[0,0,-1],[0,1,0]])
m.vertices=m.vertices@rotation.T
m.vertices-=m.bounds.mean(axis=0)
rotated_extents=m.extents.copy();p=j.properties.dimensions_m;target=np.array([p.x,p.y,p.z]);scale=target/rotated_extents
m.vertices*=scale
assert m.is_watertight and np.isfinite(m.vertices).all()
np.testing.assert_allclose(m.extents,target,rtol=1e-6)
path=root/'reconstruction/can-selected-upright.obj';m.export(path,digits=17)
record={'source_file':'mesh.glb','source_sha256':before,'derivative_file':path.name,'selection':'Largest connected surface component, visually reviewed as the central target can; three smaller components excluded','alignment':'Reviewed +90 degree rotation around X, mapping native +Y cylinder axis to simulation +Z','original_component_extents':original_extents.tolist(),'aligned_component_extents':rotated_extents.tolist(),'scale_factors':scale.tolist(),'target_dimensions_m':target.tolist(),'vertices':len(m.vertices),'faces':len(m.faces),'watertight':bool(m.is_watertight),'limitations':['No label texture: original Meshy request was geometry-only','Shape still follows generated geometry; not a measured scan','Separate scaling along cylinder height uses the saved estimated dimensions','Collision remains the current exporter box approximation']}
(root/'reconstruction/can-repair.json').write_text(json.dumps(record,indent=2))
props=j.properties.model_dump();props['dimensions_m']['note']='Selected the main can component from the cached Meshy mesh; removed three background components, rotated native +Y to +Z, and fitted to these user-confirmed estimated dimensions. Original GLB retained. See reconstruction/can-repair.json.'
store.update(j.id,mesh_path='reconstruction/can-selected-upright.obj',properties=AssetProperties.model_validate(props),status='awaiting_properties',asset=None,error=None,export_path=None,validation_path=None,bundle_path=None)
assert hashlib.sha256(raw.read_bytes()).hexdigest()==before
print(json.dumps(record,indent=2))
