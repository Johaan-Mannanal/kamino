from pathlib import Path
from uuid import UUID
import numpy as np,trimesh,mujoco
from PIL import Image,ImageDraw
from photo2sim.api.config import Settings
from photo2sim.api.store import JobStore
from photo2sim.assets.prepare import _load_mesh
s=Settings.from_env();store=JobStore(s.data_dir);j=store.get(UUID('f84d7763-8ede-40e5-8823-43da1239e7e6'));root=store.job_dir(j.id)
for name in j.source_images:
 im=Image.open(root/name);print(name,'EXIF orientation',im.getexif().get(274))
mesh,_=_load_mesh(root/j.mesh_path)
print('Raw bounds:',mesh.bounds.tolist());print('Raw vertices/faces:',len(mesh.vertices),len(mesh.faces))
print('Quantiles:',np.quantile(mesh.vertices,[0,.1,.25,.5,.75,.9,1],axis=0).tolist())
canvas=Image.new('RGB',(1200,660),'white');draw=ImageDraw.Draw(canvas)
for row,(label,path) in enumerate([('Raw Meshy output',root/j.mesh_path),('Current exported geometry',root/Path(j.export_path).parent/'meshes/visual.obj')]):
 mesh,_=_load_mesh(path)
 mesh.vertices=(mesh.vertices-mesh.bounds.mean(axis=0))*.15/mesh.extents.max()
 obj=Path('outputs/system-check')/('can-inspect-'+str(row)+'.obj');mesh.export(obj)
 xml='<mujoco><visual><headlight ambient=".4 .4 .4" diffuse=".8 .8 .8"/></visual><asset><mesh name="obj" file="'+str(obj.resolve()).replace('\\','/')+'"/></asset><worldbody><geom type="mesh" mesh="obj" rgba=".5 .7 .8 1"/></worldbody></mujoco>'
 m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);mujoco.mj_forward(m,d);ren=mujoco.Renderer(m,height=300,width=400)
 for col,(az,el) in enumerate([(110,-25),(0,-89),(0,0)]):
  cam=mujoco.MjvCamera();cam.lookat[:]=0;cam.distance=.28;cam.azimuth=az;cam.elevation=el
  ren.update_scene(d,camera=cam);canvas.paste(Image.fromarray(ren.render()),(col*400,row*330+30))
 draw.text((5,row*330+5),label,fill='black');ren.close()
canvas.save('outputs/system-check/can-mesh-comparison.png')
