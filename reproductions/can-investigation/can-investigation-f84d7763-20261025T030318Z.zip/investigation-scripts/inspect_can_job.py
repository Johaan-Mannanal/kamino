from uuid import UUID
from photo2sim.api.config import Settings
from photo2sim.api.store import JobStore
import json
from PIL import Image
from pathlib import Path
s=Settings.from_env();store=JobStore(s.data_dir);j=store.get(UUID('f84d7763-8ede-40e5-8823-43da1239e7e6'));r=store.job_dir(j.id)
print('JOB ROOT',r)
print('PHOTOS',j.source_images)
print('PROPERTIES',j.properties.model_dump_json() if j.properties else None)
for name in j.source_images:
 im=Image.open(r/name);print(name,im.size,im.format);im.thumbnail((700,700));im.convert('RGB').save(Path('outputs/system-check')/(Path(name).stem+'-input.jpg'))
print('ASSET',j.asset.model_dump_json() if j.asset else None)
print('SCENE', (r/j.export_path).read_text())
