from pathlib import Path
import numpy as np,trimesh,json
from photo2sim.assets.prepare import _load_mesh
p=Path('artifacts/photo2sim/f84d7763-8ede-40e5-8823-43da1239e7e6/reconstruction/mesh.glb')
m,_=_load_mesh(p)
# Connected components without scipy: the provider emits separate closed shells.
parent=np.arange(len(m.vertices));size=np.ones(len(parent),dtype=int)
def find(i):
 while parent[i]!=i:
  parent[i]=parent[parent[i]];i=parent[i]
 return i
def union(a,b):
 a,b=find(a),find(b)
 if a==b:return
 if size[a]<size[b]:a,b=b,a
 parent[b]=a;size[a]+=size[b]
for a,b,c in m.faces:union(a,b);union(b,c)
labels=np.array([find(i) for i in range(len(parent))]);groups=[]
for label,count in zip(*np.unique(labels,return_counts=True)):
 ids=np.flatnonzero(labels==label);f=m.faces[np.all(labels[m.faces]==label,axis=1)]
 part=trimesh.Trimesh(vertices=m.vertices.copy(),faces=f,process=False);part.remove_unreferenced_vertices()
 groups.append((float(part.area),part))
groups.sort(key=lambda x:x[0],reverse=True)
for i,(area,part) in enumerate(groups[:10]):print(i,'vertices',len(part.vertices),'area',area,'bounds',part.bounds.tolist(),'extents',part.extents.tolist())
best=groups[0][1];best.export('outputs/system-check/can-largest-raw.obj')
