from pathlib import Path
from uuid import UUID
import json,mujoco
from PIL import Image
from photo2sim.api.config import Settings
from photo2sim.api.store import JobStore
store=JobStore(Settings.from_env().data_dir);j=store.get(UUID('f84d7763-8ede-40e5-8823-43da1239e7e6'));root=store.job_dir(j.id)
scene=root/j.export_path;report=json.loads((root/j.validation_path).read_text())
print(json.dumps({k:report.get(k) for k in ['passed','scope','viewer_inspected','original','relocated']},indent=2))
m=mujoco.MjModel.from_xml_path(str(scene));d=mujoco.MjData(m);mujoco.mj_step(m,d,nstep=30000)
renderer=mujoco.Renderer(m,height=480,width=640);camera=mujoco.MjvCamera();camera.lookat[:]=[0,0,.0655];camera.distance=.3;camera.azimuth=135;camera.elevation=-25
opt=mujoco.MjvOption();opt.geomgroup[3]=0
renderer.update_scene(d,camera=camera,scene_option=opt)
Image.fromarray(renderer.render()).save('outputs/system-check/can-corrected-preview.png');renderer.close()
