from uuid import UUID
from pathlib import Path
import runpy,sys
from photo2sim.api.config import Settings
from photo2sim.api.store import JobStore
s=Settings.from_env();store=JobStore(s.data_dir)
j=store.get(UUID('f84d7763-8ede-40e5-8823-43da1239e7e6'))
if not j.export_path:raise RuntimeError('Job does not have an exported simulation')
scene=(store.job_dir(j.id)/j.export_path).resolve()
assert scene.is_file()
print('Opening generated scene: '+str(scene),flush=True)
sys.argv=['view.py','--scene',str(scene)]
runpy.run_path(str(Path('tools/simulation/view.py').resolve()),run_name='__main__')
