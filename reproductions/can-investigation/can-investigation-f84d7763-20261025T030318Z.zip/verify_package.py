from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
for item in manifest['files']:
 p=(root/item['path']).resolve()
 if not p.is_relative_to(root) or not p.is_file():raise SystemExit('Missing or invalid file: '+item['path'])
 data=p.read_bytes()
 if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:raise SystemExit('Hash mismatch: '+item['path'])
for line in (root/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1)
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:raise SystemExit('Checksum mismatch: '+name)
print('Verified '+str(len(manifest['files']))+' payload files and MANIFEST.json. No provider calls made.')
