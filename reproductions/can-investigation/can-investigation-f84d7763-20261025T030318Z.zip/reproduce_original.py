from pathlib import Path
import argparse,json,sys
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'source/current/src'))
from photo2sim.assets.prepare import prepare_asset
from photo2sim.contracts import AssetProperties
from photo2sim.simulation.export import export_asset
from photo2sim.simulation.validate import validate_export
parser=argparse.ArgumentParser(description='Reproduce original can failure locally; no provider calls or manual repair.')
parser.add_argument('--output',type=Path,default=Path('reproduced-original'))
args=parser.parse_args();out=args.output.resolve()
if out.exists():raise SystemExit('Refusing to overwrite existing output directory')
properties=AssetProperties.model_validate_json((root/'original/properties.json').read_text())
asset=prepare_asset(root/'original/reconstruction/mesh.glb',out/'prepared',properties)
scene=export_asset(asset,out/'prepared',out/'bundle')
report=validate_export(scene)
(scene.parent/'validation-report.json').write_text(json.dumps(report,indent=2)+'\n')
print('Reproduced original preparation at '+str(scene))
print('Physics passed: '+str(report.get('passed'))+'; this does not validate the can geometry.')
for note in asset.notes:print(note)
