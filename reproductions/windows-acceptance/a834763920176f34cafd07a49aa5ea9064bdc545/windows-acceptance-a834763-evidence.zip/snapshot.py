import json,sys,time,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
base='http://127.0.0.1:8002/api/jobs/c25fcbbd-cec8-4065-ab36-d829fd9be888'
name=sys.argv[1]
req=urllib.request.Request(base,headers={'Authorization':'Bearer ui-acceptance-only'})
with opener.open(req,timeout=30) as r:job=json.load(r)
(root/'api').mkdir(exist_ok=True)
(root/'api'/f'{name}-job.json').write_text(json.dumps(job,indent=2))
print(json.dumps({k:job.get(k) for k in ['id','status','input_revision','orientation','geometry_review','properties','sizing_result','active_attempt_id','error']},indent=2))
