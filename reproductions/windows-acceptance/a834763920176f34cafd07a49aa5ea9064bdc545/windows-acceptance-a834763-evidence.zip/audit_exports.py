"""Read-only acceptance audit of actual browser downloads; no application imports."""
import hashlib, json, os, sys, zipfile
from pathlib import Path, PurePosixPath
import xml.etree.ElementTree as ET
import numpy as np
import trimesh
root = Path(__file__).resolve().parent
relocated = Path((root/'exports/relocated-path.txt').read_text().strip())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
out = {'relocated': str(relocated), 'zip_hashes': {}, 'bundles': {}}
for p in sorted((root/'exports').glob('*.zip')):
    out['zip_hashes'][p.name] = sha(p)
    with zipfile.ZipFile(p) as z:
        members = z.namelist()
        assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and ':' not in n and '\\' not in n for n in members)
        asset=json.loads(z.read('asset.json'))
        inputs=json.loads(z.read('inputs.json'))
        sim=json.loads(z.read('simulation.json'))
        report=json.loads(z.read('validation-report.json'))
        out['bundles'][p.name]={'members':members,'asset':asset,'inputs':inputs,'simulation':sim,'report':report}
assert out['zip_hashes']['A.zip']==out['zip_hashes']['A-redownload-after-B.zip']
out['A_preserved_after_B']=True
scene=ET.parse(relocated/'scene.xml')
refs=[]
for node in scene.iter():
    if 'file' in node.attrib:
        ref=node.attrib['file']; target=(relocated/ref).resolve()
        assert target.is_relative_to(relocated.resolve()) and target.is_file()
        refs.append({'reference':ref,'sha256':sha(target)})
mesh=trimesh.load(relocated/'meshes/visual.obj',force='mesh',process=False)
asset=json.loads((relocated/'asset.json').read_text())
sizing=asset['sizing_result']
derived=np.array(sizing['source_extents_input_units'])*np.array(sizing['scale_factors'])
error=np.abs(mesh.extents-derived)
assert float(error.max())<1e-7
out.update({'local_references':refs,'extracted_hashes':{str(p.relative_to(relocated)):sha(p) for p in relocated.rglob('*') if p.is_file()},'exported_extents_m':mesh.extents.tolist(),'calculated_extents_m':derived.tolist(),'max_extent_error_m':float(error.max()),'tolerance_m':1e-7,'visual_vertices':len(mesh.vertices),'visual_faces':len(mesh.faces),'visual_mesh_sha256':sha(relocated/'meshes/visual.obj'),'historical_comparison_m':[.057,.057,.131],'physical_accuracy':'unverified; derived diameter differs from historic estimate; box proxy validation does not establish shape accuracy'})
(root/'exports/audit.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ('bundles','extracted_hashes')},indent=2))
