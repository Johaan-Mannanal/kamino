"""Read-only source/data evidence collection; never updates the acceptance job."""
from pathlib import Path
import json, shutil, subprocess, hashlib
root=Path(__file__).resolve().parent
checkout=root.parents[1]/'acceptance-checkouts/kamino-a834763'
data=checkout/'outputs/ui-integration/w/data'
job_id='c25fcbbd-cec8-4065-ab36-d829fd9be888'
job=json.loads((root/'api/FINAL-job.json').read_text())
assert job['status']=='completed' and job['input_revision']==17
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip()
status=subprocess.check_output(['git','status','--short'],cwd=checkout,text=True)
assert head=='a834763920176f34cafd07a49aa5ea9064bdc545' and not status.strip()
(root/'setup/final-source-identity.txt').write_text(head+'\nstatus: clean\n')
for name in ['combined-release-windows-acceptance.md','combined-release-master-verification.md','windows-can-acceptance-checklist.md']:
    dest=root/'pinned-docs'/name; dest.parent.mkdir(exist_ok=True)
    shutil.copyfile(checkout/'docs/handoffs'/name,dest)
for name in ['ui_acceptance_server.py','ui_acceptance_fixture.py']:
    shutil.copyfile(checkout/'tools'/name,root/'pinned-docs'/name)
shutil.copyfile(data/job_id/'offline-can-fixture.json',root/'offline-can-fixture.json')
shutil.copyfile(data/job_id/'suggestions/gemini.json',root/'api/final-unknown-suggestion-cache.json')
for a in job['attempts']:
    dest=root/'attempt-records'/a['id']; dest.mkdir(parents=True,exist_ok=True)
    source=data/job_id/'attempts'/a['id']
    for name in ['inputs.json','bundle/asset.json','bundle/simulation.json','bundle/validation-report.json','bundle/scene.xml']:
        p=source/name
        if p.exists(): shutil.copyfile(p,dest/name.replace('/','-'))
ledger=data.parent/'blocked-network.jsonl'
isolation={'helper':'pinned-docs/ui_acceptance_server.py','provider':'MockProvider','meshy_key':'explicit empty','gemini_key':'explicit empty','gemini_transport':'blocked_gemini_transport raises before transport','socket_guard':'non-loopback DNS/connect denied and logged','ledger_path':str(ledger),'denied_external_ledger_exists':ledger.exists(),'denied_external_entries':ledger.read_text().splitlines() if ledger.exists() else [],'observed_provider_calls':0,'scope':'acceptance application processes only; no OS-wide packet capture'}
assert not isolation['denied_external_entries'], 'Investigate any denied external attempt'
(root/'provider-isolation.json').write_text(json.dumps(isolation,indent=2))
photos={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (data/job_id/'uploads').glob('*.jpg')}
(root/'setup/final-photo-hashes.json').write_text(json.dumps(photos,indent=2))
print('Clean pinned source, completed revision 17, four attempts, original-input receipts and isolation evidence collected.')
