"""Optional, explicit property assistance; confirmed job inputs stay untouched."""

import json
from datetime import UTC, datetime
from pathlib import Path
from threading import BoundedSemaphore
from uuid import UUID

from PIL import Image, ImageOps
from pydantic import Field

from photo2sim.api.config import Settings
from photo2sim.api.store import JobStore
from photo2sim.contracts import Contract, bundle_path
from photo2sim.integrations.gemini import (
    GeminiUnavailable,
    PropertySuggestions,
    Transport,
    suggest_properties_result,
)


class SuggestionRequest(Contract):
    object_hint: str | None = Field(default=None, max_length=2000)
    refresh: bool = False


class SuggestionsBusy(RuntimeError):
    pass


def failure_details(reason: str) -> dict:
    """Public allowlisted categories; never echo provider messages or exceptions."""
    messages = {
        "not_configured": (
            "Gemini is not configured. Ask the server operator to configure it.",
            False,
        ),
        "authentication": (
            "Gemini authentication failed. Ask the server operator to update its API key.",
            False,
        ),
        "permission": (
            "Gemini access was denied. Ask the server operator to check API permissions.",
            False,
        ),
        "billing": (
            "Gemini billing is unavailable. Ask the server operator to check credits and billing.",
            False,
        ),
        "quota": (
            "Gemini quota is exhausted. Wait for its reset or ask the server operator to check quota.",
            False,
        ),
        "invalid_request": (
            "Gemini rejected the request. Revise the object hint or ask the server operator to check configuration.",
            False,
        ),
        "malformed": (
            "Gemini returned an invalid or incomplete response. Retry explicitly or continue manually.",
            False,
        ),
        "overload": ("Gemini is overloaded. Try again shortly.", True),
        "rate_limit": ("Gemini is temporarily rate limited. Wait before retrying.", True),
        "deadline": ("Gemini exceeded the request time budget. Try again shortly.", True),
        "network": ("Gemini could not be reached. Check connectivity and try again.", True),
        "busy": ("Gemini requests are still finishing. Wait before retrying.", True),
        "model_unavailable": (
            "The configured Gemini models are unavailable. Ask the server operator to check model configuration.",
            False,
        ),
        "provider": ("Gemini suggestions are unavailable. Try again later.", True),
    }
    category = reason if reason in messages else "provider"
    message, retryable = messages[category]
    return {
        "detail": f"{message} Manual property entry remains available.",
        "category": category,
        "retryable": retryable,
        "manual_entry_available": True,
    }


class SuggestionService:
    def __init__(self, store: JobStore, settings: Settings, transport: Transport | None = None):
        self.store = store
        self.settings = settings
        self.transport = transport
        self.inference_slot = BoundedSemaphore(1)

    def folder(self, job_id: UUID) -> Path:
        root = self.store.job_dir(job_id).resolve()
        folder = (root / "suggestions").resolve()
        if not folder.is_relative_to(root):
            raise ValueError("Suggestion files must remain inside the job directory")
        return folder

    def cached(self, job_id: UUID) -> dict | None:
        try:
            path = self.folder(job_id) / "gemini.json"
            if path.is_symlink():
                return None
            record = json.loads(path.read_text(encoding="utf-8"))
            PropertySuggestions.model_validate(record["suggestions"])
            return record
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def matching_cache(
        self, job_id: UUID, request: SuggestionRequest
    ) -> PropertySuggestions | None:
        cached = self.cached(job_id)
        legacy_model = cached.get("model") if cached is not None else None
        requested_model = cached.get("requested_model") if cached is not None else None
        model_matches = (
            requested_model == self.settings.gemini_model
            and tuple(cached.get("fallback_models", ())) == self.settings.gemini_fallback_models
            if requested_model is not None
            else legacy_model in (self.settings.gemini_model, *self.settings.gemini_fallback_models)
        )
        if (
            not request.refresh
            and cached is not None
            and model_matches
            and (cached.get("object_hint") or None) == (request.object_hint or None)
        ):
            return PropertySuggestions.model_validate(cached["suggestions"])
        return None

    def generate(self, job_id: UUID, request: SuggestionRequest) -> PropertySuggestions:
        cached = self.matching_cache(job_id, request)
        if cached is not None:
            return cached
        if not self.settings.gemini_api_key:
            raise GeminiUnavailable("Gemini is not configured", reason="not_configured")
        if not self.inference_slot.acquire(blocking=False):
            raise SuggestionsBusy
        try:
            # Another request may have finished between our initial read and claim.
            cached = self.matching_cache(job_id, request)
            if cached is not None:
                return cached
            paths = self.image_copies(job_id)
            result = suggest_properties_result(
                paths,
                request.object_hint,
                api_key=self.settings.gemini_api_key,
                model=self.settings.gemini_model,
                fallback_models=self.settings.gemini_fallback_models,
                max_attempts=self.settings.gemini_max_attempts,
                deadline_seconds=self.settings.gemini_deadline_seconds,
                backoff_seconds=self.settings.gemini_backoff_seconds,
                transport=self.transport,
            )
            record = {
                "model": result.model,
                "requested_model": result.requested_model,
                "fallback_models": list(self.settings.gemini_fallback_models),
                "fallback_used": result.fallback_used,
                "object_hint": request.object_hint,
                "created_at": datetime.now(UTC).isoformat(),
                "suggestions": result.suggestions.model_dump(mode="json"),
            }
            folder = self.folder(job_id)
            temporary = folder / "gemini.json.partial"
            temporary.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
            temporary.replace(folder / "gemini.json")
            return result.suggestions
        finally:
            self.inference_slot.release()

    def image_copies(self, job_id: UUID) -> list[Path]:
        job = self.store.get(job_id)
        if not 1 <= len(job.source_images) <= 4:
            raise ValueError("The job requires one to four source images")
        root = self.store.job_dir(job_id).resolve()
        copies = []
        for index, relative in enumerate(job.source_images):
            source = (root / bundle_path(relative)).resolve(strict=True)
            if not source.is_relative_to(root) or not source.is_file():
                raise ValueError("Source image must remain inside the job directory")
            with Image.open(source) as original:
                if original.width * original.height > 25_000_000:
                    raise ValueError("Source image exceeds 25 MP")
                image = ImageOps.exif_transpose(original).convert("RGB")
                image.thumbnail((1024, 1024))
                folder = self.folder(job_id) / "images"
                folder.mkdir(parents=True, exist_ok=True)
                target = folder / f"{index:02}.jpg"
                image.save(target, format="JPEG", quality=90)
                copies.append(target)
        return copies
