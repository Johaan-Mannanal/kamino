from pathlib import Path
import subprocess,hashlib,json
root=Path.cwd()
sha='a834763920176f34cafd07a49aa5ea9064bdc545'
out=root/'outputs/windows-acceptance-results'/sha/'frontend'
meta=[]
for label,folder in [('legacy','frontend'),('workspace','prototypes/kamino-ui')]:
 target=out/'prefetch'/label;target.mkdir(parents=True,exist_ok=True)
 for filename in ['package.json','pnpm-lock.yaml','pnpm-workspace.yaml']:
  raw=subprocess.check_output(['git','show',sha+':'+folder+'/'+filename])
  (target/filename).write_bytes(raw)
  meta.append({'source':folder+'/'+filename,'source_commit':sha,'prefetch_path':str(target/filename),'sha256':hashlib.sha256(raw).hexdigest()})
(out/'prefetch-source-identity.json').write_text(json.dumps(meta,indent=2))
print('Pinned metadata copied byte-for-byte for dependency-cache prefetch only.')
