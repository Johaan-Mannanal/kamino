from pathlib import Path
from datetime import datetime, timezone
import json,hashlib,subprocess
root=Path(r'C:\Users\srija\calhacks-arm\outputs\acceptance-checkouts\kamino-a834763')
out=Path(r'C:\Users\srija\calhacks-arm\outputs\windows-acceptance-results\a834763920176f34cafd07a49aa5ea9064bdc545\frontend')
sha='a834763920176f34cafd07a49aa5ea9064bdc545'
actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip();assert actual==sha
status=subprocess.check_output(['git','status','--short'],cwd=root).decode();assert not status,status
(out/'git-status-after-frontend.txt').write_text(status)
versions={};artifacts=[]
for label,folder in [('legacy','frontend'),('workspace','prototypes/kamino-ui')]:
 p=root/folder
 installed={}
 for name in ['three','@types/three','jsdom','typescript','vite','vitest','prettier','playwright']:
  pkg=p/'node_modules'/name/'package.json'
  if pkg.is_file():installed[name]=json.loads(pkg.read_text())['version']
 versions[label]=installed
 for name in ['package.json','pnpm-lock.yaml','pnpm-workspace.yaml']:
  a=(p/name).read_bytes();b=(out/'prefetch'/label/name).read_bytes();assert a==b,name
 for file in sorted((p/'dist').rglob('*')):
  if file.is_file():artifacts.append({'app':label,'file':file.relative_to(root).as_posix(),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
result={'source_commit':sha,'completed_at_utc':datetime.now(timezone.utc).isoformat(),'source_status_clean':True,'node':'v24.20.0','pnpm':'11.25.0','clean_frozen_lockfile_install':{'legacy':{'exit_code':0,'packages':97,'downloads':0,'offline':True},'workspace':{'exit_code':0,'packages':98,'downloads':0,'offline':True}},'legacy_tests':{'passed':103,'failed':0,'files':18,'exit_code':0},'workspace_tests':{'passed':99,'failed':0,'files':7,'exit_code':0},'legacy_typecheck_and_build':{'passed':True,'exit_code':0},'workspace_typecheck_and_build':{'passed':True,'exit_code':0},'build_warnings':['Both builds emit the existing >500kB chunk-size warning. No warning threshold or application code was changed.'],'installed_direct_packages':versions,'build_artifacts':artifacts,'application_source_edits':False,'provider_calls':0,'scope':'Native test/build supporting evidence only; does not replace integrated UI acceptance.'}
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['build_artifacts','installed_direct_packages']},indent=2))
