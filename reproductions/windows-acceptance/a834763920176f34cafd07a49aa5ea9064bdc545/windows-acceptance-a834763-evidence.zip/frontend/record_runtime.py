from pathlib import Path
import json,subprocess,platform,datetime
p=Path('outputs/windows-acceptance-results/a834763920176f34cafd07a49aa5ea9064bdc545/frontend')
p.joinpath('setup-runtime.json').write_text(json.dumps({'source_commit':'a834763920176f34cafd07a49aa5ea9064bdc545','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'node':subprocess.check_output(['node','--version']).decode().strip(),'pnpm':subprocess.check_output(['pnpm.cmd','--version']).decode().strip(),'dependency_setup_tls':'NODE_USE_SYSTEM_CA=1; certificate verification enabled','prefetch_only':True,'application_tests_started':False,'application_sources_modified':False,'provider_calls':0},indent=2))
