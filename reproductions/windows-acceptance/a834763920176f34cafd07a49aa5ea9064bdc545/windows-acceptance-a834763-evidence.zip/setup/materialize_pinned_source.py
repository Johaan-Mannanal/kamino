from pathlib import Path,PurePosixPath
import ssl,httpx,hashlib,json,zipfile,subprocess,time
sha='a834763920176f34cafd07a49aa5ea9064bdc545'
r=Path('outputs/windows-acceptance-results')/sha/'setup';dest=Path('outputs/acceptance-checkouts/kamino-a834763').resolve();archive=r/'pinned-source.zip'
with httpx.Client(verify=ssl.create_default_context(),timeout=180,follow_redirects=True) as c:
 with c.stream('GET','https://codeload.github.com/Johaan-Mannanal/kamino/zip/'+sha) as response:
  response.raise_for_status()
  with archive.open('wb') as f:
   for data in response.iter_bytes():f.write(data)
print('Source ZIP bytes',archive.stat().st_size,flush=True)
items=subprocess.check_output(['git','ls-tree','-r','-z',sha]).split(b'\0');expected={}
for item in items:
 if not item:continue
 meta,path=item.split(b'\t',1);mode,typ,oid=meta.decode().split();assert typ=='blob';expected[path.decode()]=(mode,oid)
actual={}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for item in z.infolist():
  parts=PurePosixPath(item.filename).parts
  if item.is_dir() or len(parts)<2:continue
  rel=PurePosixPath(*parts[1:]).as_posix();assert rel in expected,rel
  data=z.read(item);oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  assert oid==expected[rel][1],'Blob mismatch: '+rel
  target=dest/rel;assert target.resolve().is_relative_to(dest);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  actual[rel]={'git_blob_sha1':oid,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
assert set(actual)==set(expected),'Missing tracked files: '+str(set(expected)-set(actual))
# Populate missing promisor blobs from already verified source bytes, then build the index.
paths=''.join(str(dest/rel)+'\n' for rel in actual)
proc=subprocess.run(['git','hash-object','-w','--no-filters','--stdin-paths'],input=paths,text=True,capture_output=True)
assert proc.returncode==0,proc.stderr
subprocess.run(['git','-C',str(dest),'read-tree',sha],check=True)
status=subprocess.check_output(['git','-C',str(dest),'status','--porcelain=v1']).decode()
assert not status,status
(r/'tracked-source-manifest.json').write_text(json.dumps({'commit':sha,'download_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':actual},indent=2))
(r/'checkout-identity.txt').write_text(subprocess.check_output(['git','-C',str(dest),'rev-parse','HEAD']).decode()+'status: clean\n')
print('Exact tracked source verified:',len(actual),'files; isolated checkout clean.',flush=True)
