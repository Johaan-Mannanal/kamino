from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
r=Path('outputs/windows-acceptance-results/a834763920176f34cafd07a49aa5ea9064bdc545')
p=r/'HANDOFF.md';s=p.read_text(encoding='utf-8-sig')
s=s.replace('from cached Git objects plus individually retrieved missing assets','from cached Git objects (the per-blob recovery found zero still-missing blobs)')
s=s.replace('`run-record.md` in this evidence folder currently remains the **untouched 28-row NOT RUN template**. Parent alone fills observed final results.','`run-record.md` retains 28 conservatively ungraded NOT RUN rows, with an appended partial-execution checkpoint. The full acceptance pass is IN PROGRESS, not complete. The continuing agent must fill observed final results.')
latest='''
## LATEST SAFE CHECKPOINT — read before continuing

Checkpoint recorded after the user requested a detailed handoff if context is low. This is the **same one acceptance pass**, not a new run. No generation has been attempted yet. No A/B export or final ZIP exists for this Windows job.

### New observations after the earlier revision-6 checkpoint

- P02: explicit friction **0** was saved with estimated provenance at input revision 6 (`api/P02-zero-friction-saved-job.json`).
- P02: entering **-0.1** showed “Friction must be zero or greater, or blank if unknown”; Save/Generate were disabled. A tool click on the disabled Save timed out; it did not issue a save. `ui/P02-negative-friction-blocked.*` is the evidence.
- P02: valid test friction **0.4** was saved at revision 7 (`api/P02-positive-friction-saved-job.json`, `ui/P02-positive-friction-saved.*`). Then blank friction was explicitly saved and became **null** at revision 8.
- D01: drafted reference **140 mm**, mass **0.3 kg**, friction **0.4** without saving. UI showed “Draft · Unsaved changes”; Generate was disabled with “Save reviewed properties before generating.” `ui/D01-unsaved-reference-mass-friction.*` and `api/D01-unsaved-server-unchanged-job.json` prove the server stayed at **131 mm**, **0.26 kg**, **null** (revision 8), not the draft values.
- D03: `acceptanceTab.reload()` returned with unchanged draft UI and no exposed JS dialog; the backend request log showed no fresh page-restoration GET. **Do not claim browser-refresh persistence/discard was tested successfully.** The browser adapter may have canceled a beforeunload prompt; the actual reason remains unproven. Evidence: `ui/D03-reload-unproven-draft-retained.*`. A new-tab reopen can still be tested, but it is not a substitute for actual refresh/unsaved-discard behavior.
- At the safe stop, the temporary draft fields were manually returned to **131**, **0.26**, and blank friction **without clicking Save**. Server state remains revision 8. The browser still showed its dirty indicator after editing back to matching values; do not treat field equality as a save or silently clear it. Evidence: `ui/CHECKPOINT-saved-values-restored-no-generation.*`.

### Authoritative saved state at stop

- Job `c25fcbbd-cec8-4065-ab36-d829fd9be888`, status `awaiting_properties`, input revision **8**.
- Main can surface UI label **Surface 3**, selected based on its blue highlighted central-can geometry/photo comparison, not merely the ordinal. Saved island ID `2c8782adb8e2deeaf252e5c1ba0611a71c7d5c729c01e41927f770430fc2edf7`.
- Source raw GLB remains `5b9ced8ce875c19b18abd171ce328959a443e6eb3103a21202f94280081bf6ec`.
- Saved orientation: X=90°, Y=0°, Z=0°.
- Saved geometry context: `b6d3c138af9f3e62b58cfd935aef72e02028a4c679d709e205b0d8f7494ae12e`.
- One explicitly reviewed **estimated** full-Z reference: **131 mm**. This is a QA use of a historical estimate, not measured ground truth.
- Equal scale factors: **0.07178149522642335** on all axes.
- Derived extents: **29.79368293108149 × 29.806611520258652 × 131 mm**. Do not force the diameter to 57 mm or use the manual nonuniform derivative as the target.
- Saved mass **0.26 kg**, estimated; friction **null**. Source selected extents `[0.41506077349185944, 0.4152408838272095, 1.8249828815460205]`.
- No active attempt; no error; no provider task imported; no provider calls observed in acceptance.

### Resume priorities

1. Read the pinned handoff/checklist and this file; verify clean exact HEAD and confirm the two isolated services still point to this checkout/data directory.
2. Read the latest saved record through the local API or `snapshot.py`. Preserve current evidence. If using a new browser tab/chat, use the exact job URL and local dummy token; never connect the old IPv4 Workspace service or port8001 server.
3. Finish S02 visual orbit/top/underside and S03/O02 selection-change invalidation plus reference re-review. Empty selection and selected-target saving were already observed; do not restart the entire pass.
4. Finish D02/D03 refresh/reopen evidence, D04 failed-save/restart/retry, and positive/null/unavailable Gemini P03–P05 via the **supplied cache seeder**. No live provider calls or injected app patches. The prior reload ambiguity remains a limitation until resolved with supported browser behavior.
5. Generate A only through the delivered UI after a reviewed save; download and hash A. Correct/save/regenerate B, retrieve A byte-identically, download B through the browser, relocate/extract and perform real MuJoCo GUI inspection. Do not count a direct API save/process script as UI behavior.
6. R03, provider-failure part of R04, and unsupported malformed/quota/HTTP portions of P05 are BLOCKED under the handoff, not mock/unit-test passes. R05 requires a genuine in-flight interruption; if unavailable without source/data manipulation, mark BLOCKED.
7. Complete **all 28 rows** with evidence and honest PASS/FAIL/BLOCKED, recording any partial unsupported subcases. No final results have been adjudicated yet. Native automated failures and short-temp diagnostic remain separate supporting records.
8. Create and return a real evidence ZIP and completed run record. Exclude 750MB `backend/offline-wheelhouse/`, prefetch node_modules, venvs, partial sourceZIP, internal caches and credentials. Include useful source identity manifests, test/diagnostic logs, Claude review ledger/output, screenshots/DOM/API records, final A/B ZIPs/reports and hashes. Physical accuracy remains unverified.

### Safe service and browser details

- Backend: loopback **127.0.0.1:8002**; current wrapper PID was 52556 and Uvicorn child PID **56116**. Discover/verify current owning PID before stopping; never trust a stale PID alone.
- Backend data: isolated checkout **`outputs/ui-integration/w/data`**. The earlier full-SHA data copy was setup-only and is stale now. Do not resume using it.
- Backend commands: `.venv-acceptance/Scripts/python.exe -m tools.ui_acceptance_server --data-dir outputs/ui-integration/w/data --port 8002`, working directory the exact checkout, `PYTHONPATH=src;.`. Explicit helper settings have empty provider keys and deny non-loopback sockets.
- Backend logs: evidence root `backend-ui-short-out.log` (request access output) and `backend-ui-short-access.log` (startup/error output). Initial full-SHA setup logs are also retained but are not the current data service.
- Workspace: same checkout `prototypes/kamino-ui`, Node Vite bound **IPv6 ::1 port5188**, original exec session 9199. Environment: `VITE_API_BASE_URL=http://127.0.0.1:8002`, `VITE_API_MODE=live`. Open **http://localhost:5188/?job=c25fcbbd-cec8-4065-ab36-d829fd9be888#workspace**. IPv6 intentionally avoids existing IPv4 port5188 app. The loaded fixture job confirms the new backend, not old port8001.
- Dummy local token: **`ui-acceptance-only`**; not a provider credential. It is memory-only per tab and may need re-entry on reopening.
- Existing IPv4 ports **8001/5188/5173** belong to pre-existing local apps; do not stop, modify, or substitute them.
- This chat's IAB tab was **2**, marked for handoff; `acceptanceTab`, `qaFs`, `qaUiDir`, and `qaCapture` were CUA variables, not portable new-chat bindings. In a new chat, discover/select the appropriate browser/tab or create a new local tab. Do not assume tab2 belongs to the new session.
- Use viewport JPEG screenshots (`fullPage:false`), plus DOM snapshots. Initial full-page screenshots reflowed/cropped the 3D/scroll layout and are not reliable proof of visible controls. The target controls are below the main preview in the page; Playwright locators scroll them into view.
- Browser read-only DOM evaluation is allowed for observation only. Do not inject handlers, change DOM/state or synthesize application behavior through evaluate. Use the supported browser/CUA tools for actual UI and native MuJoCo actions.

Suggested new-chat request: “Continue the existing single Windows acceptance pass from this HANDOFF.md at exact a834763920176f34cafd07a49aa5ea9064bdc545. Preserve all prior evidence and app source. Complete only the remaining checks, mark unsupported cases BLOCKED, and return the completed record plus an evidence ZIP.”
'''
s='LATEST CHECKPOINT: saved revision 8; read the final LATEST SAFE CHECKPOINT section before acting.\n\n'+s+'\n'+latest
p.write_text(s,encoding='utf-8')
record=r/'run-record.md';t=record.read_text(encoding='utf-8-sig')
t=t.replace('**Status: NOT RUN.** This is a blank reusable execution record. Existing can evidence and earlier tests are not results for Johaan/Atul\'s upcoming integrated commit.','**Status: IN PROGRESS — partial manual execution checkpoint, not a completed acceptance result.** Rows remain NOT RUN until full-row results are adjudicated; observed substeps and evidence are recorded in HANDOFF.md. Do not infer that no actions occurred or count the earlier manual repair/master tests as acceptance.')
t += '\n## Partial execution checkpoint\n\nPinned exact SHA: `a834763920176f34cafd07a49aa5ea9064bdc545`. See [HANDOFF.md](HANDOFF.md), especially its final LATEST SAFE CHECKPOINT section, for live services, authoritative revision-8 job state, observed UI substeps and remaining checks. The 28-row result table is not finalized.\n\nSupporting native evidence: frontend103+99 tests and both builds passed; initial backend365 passed/25 failed/7 skipped. A separate short-temp diagnostic passed all25 previously failed cases; it does not waive the initial results or establish a fix. No application source changed. No A/B generation, final ZIP or relocated viewer acceptance has occurred yet.\n'
record.write_text(t,encoding='utf-8')
checkpoint={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'commit':'a834763920176f34cafd07a49aa5ea9064bdc545','job_id':'c25fcbbd-cec8-4065-ab36-d829fd9be888','saved_input_revision':8,'ui_draft_values_match_saved_but_dirty_flag_persists':True,'generations_attempted':0,'gemini_cache_seeded':False,'manual_pass_complete':False,'handoff':'HANDOFF.md'}
(r/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2))
status=subprocess.check_output(['git','-C','outputs/acceptance-checkouts/kamino-a834763','status','--porcelain=v1']).decode();assert status=='',status
print('Detailed handoff and partial run record updated. Exact application checkout remains clean.')
