from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,hashlib,json,ssl,httpx,time,re
from urllib.parse import quote
sha='a834763920176f34cafd07a49aa5ea9064bdc545';dest=Path('outputs/acceptance-checkouts/kamino-a834763').resolve();r=Path('outputs/windows-acceptance-results')/sha/'setup'
entries={}
for line in subprocess.check_output(['git','ls-tree','-r','-z',sha]).split(b'\0'):
 if not line:continue
 meta,p=line.split(b'\t',1);mode,typ,oid=meta.decode().split();assert typ=='blob';entries[p.decode()]=oid
available={line.decode().split()[0] for line in subprocess.check_output(['git','cat-file','--batch-all-objects','--batch-check=%(objectname) %(objecttype)']).splitlines()}
byoid={}
for p,oid in entries.items():byoid.setdefault(oid,[]).append(p)
manifest={};missing=[]
proc=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for oid,paths in byoid.items():
 if oid not in available:missing.append((oid,paths));continue
 proc.stdin.write((oid+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().strip().split();size=int(header[2]);data=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n'
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
 for rel in paths:
  p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);manifest[rel]={'git_blob_sha1':oid,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
proc.stdin.close();proc.wait()
print('Materialized cached source files:',len(manifest),'missing unique blobs:',len(missing),flush=True)
(r/'missing-blobs.json').write_text(json.dumps(missing,indent=2))
context=ssl.create_default_context()
def download(item):
 oid,paths=item;url='https://raw.githubusercontent.com/Johaan-Mannanal/kamino/'+sha+'/'+quote(paths[0],safe='/');cache=r/(oid+'.blob')
 data=None
 for attempt in range(4):
  try:
   offset=cache.stat().st_size if cache.exists() else 0
   with httpx.Client(verify=context,timeout=120,follow_redirects=True) as c:
    with c.stream('GET',url,headers={'Range':f'bytes={offset}-{offset+1048575}'}) as response:
     response.raise_for_status();append=response.status_code==206 and offset>0
     if response.status_code==206:
      cr=response.headers.get('content-range','');total=int(cr.split('/')[-1]);assert int(cr.split()[1].split('-')[0])==offset
     else:total=None
     with cache.open('ab' if append else 'wb') as f:
      for chunk in response.iter_bytes():f.write(chunk)
   if total is not None and cache.stat().st_size<total:
    # Continue remaining ranges within this download attempt.
    while cache.stat().st_size<total:
     offset=cache.stat().st_size
     with httpx.Client(verify=context,timeout=120,follow_redirects=True) as c:
      rr=c.get(url,headers={'Range':f'bytes={offset}-{min(total-1,offset+1048575)}'});rr.raise_for_status();assert rr.status_code==206;assert int(rr.headers['content-range'].split()[1].split('-')[0])==offset
      with cache.open('ab') as f:f.write(rr.content)
   data=cache.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   assert actual==oid,(paths[0],len(data),actual)
   break
  except Exception as e:
   print('Retry asset',paths[0],type(e).__name__,flush=True)
   if attempt==3:raise
   time.sleep(1)
 for rel in paths:
  p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 print('Verified downloaded asset:',paths[0],len(data),'bytes',flush=True)
 return {rel:{'git_blob_sha1':oid,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for rel in paths}
with ThreadPoolExecutor(max_workers=4) as pool:
 for f in as_completed([pool.submit(download,item) for item in missing]):manifest.update(f.result())
assert set(manifest)==set(entries)
paths=''.join(str(dest/rel)+'\n' for rel in entries)
p=subprocess.run(['git','hash-object','-w','--no-filters','--stdin-paths'],input=paths,text=True,capture_output=True);assert p.returncode==0,p.stderr
subprocess.run(['git','-C',str(dest),'read-tree',sha],check=True)
status=subprocess.check_output(['git','-C',str(dest),'status','--porcelain=v1']).decode();assert not status,status
(r/'tracked-source-manifest.json').write_text(json.dumps({'commit':sha,'materialization':'Local Git objects plus individual pinned GitHub blobs; every Git blob hash verified','files':manifest},indent=2))
(r/'checkout-identity.txt').write_text(subprocess.check_output(['git','-C',str(dest),'rev-parse','HEAD']).decode()+'status: clean\n')
print('Exact checkout verified clean:',len(manifest),'tracked files.',flush=True)
