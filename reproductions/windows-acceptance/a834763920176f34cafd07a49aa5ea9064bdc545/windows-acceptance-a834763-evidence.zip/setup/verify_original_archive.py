from pathlib import Path,PurePosixPath
from zipfile import ZipFile
import subprocess,sys
r=Path('outputs/windows-acceptance-results/a834763920176f34cafd07a49aa5ea9064bdc545');dest=r/'archive-evidence'
assert not dest.exists()
with ZipFile(r/'can-fixture.zip') as z:
 for name in z.namelist():
  p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and ':' not in name
 z.extractall(dest)
result=subprocess.run([sys.executable,str(dest/'verify_package.py')],text=True,capture_output=True)
(r/'setup/archive-verification.log').write_text(result.stdout+result.stderr)
print(result.stdout)
assert result.returncode==0
