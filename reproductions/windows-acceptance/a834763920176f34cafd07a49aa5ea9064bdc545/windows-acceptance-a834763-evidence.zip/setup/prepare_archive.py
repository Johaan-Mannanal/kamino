from pathlib import Path
import subprocess,hashlib,json
r=Path('outputs/windows-acceptance-results/a834763920176f34cafd07a49aa5ea9064bdc545');p=r/'can-fixture.zip'
source=Path('outputs/reproduction-packages/can-investigation-f84d7763-20261025T030318Z.zip')
data=source.read_bytes() if source.is_file() else subprocess.check_output(['git','show','44e3aec1346c520c272a9b39fc7f665330fcfae6:reproductions/can-investigation/can-investigation-f84d7763-20261025T030318Z.zip'])
assert hashlib.sha256(data).hexdigest()=='e828bb548dae9e5828a29689f2e91c96f4069ee4c6aa8b5788a5700d2d01db6d'
p.write_bytes(data)
print('Original archive verified and copied; no source or job data changed.')
