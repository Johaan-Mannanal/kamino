# Read-only acceptance coverage review, Kamino `a834763920176f34cafd07a49aa5ea9064bdc545`

I used only Read, Glob and Grep. I ran no code and credit no test as PASS. Physical accuracy remains unverified. 57/57/131 mm values are comparison estimates only (`windows-can-acceptance-checklist.md:36-40`).

Paths below are relative to the sandbox root. The abbreviations are:
- **ACC** = `docs/handoffs/combined-release-windows-acceptance.md`
- **CL** = `docs/handoffs/windows-can-acceptance-checklist.md`
- **MV** = `docs/handoffs/combined-release-master-verification.md`

The worker (`api/worker.py`), `store.py`, `rigid_history.py`, `assets/sizing.py` and the frontend are not in the sandbox. Anything that depends on them is unverifiable from here.

## 1. Unsupported by the helpers: record BLOCKED, do not credit from mocks or unit tests

ACC:92 and ACC:102 say arbitrary failure injection is not provided and unsupported rows should be BLOCKED. MV:36 says the same. Beyond that:

| ID / subscenario | Why unsupported |
|---|---|
| **D04** (failed save, then retry) | Partly supported. ACC:102 offers stopping the isolated backend, attempting a save, restarting and retrying. There is no injection endpoint. A stopped server gives a network failure only, not a server-rejected save. Record the limit. |
| **R03** (replay validation/preparation failure fixture, retry via cached mesh) | ACC:102: "this helper does not provide an integrated failure-injection endpoint". CL:34 allows only UI-mock coverage, which CL:99 says is not backend coverage. The retryable codes are listed at `app.py:38-51`, but nothing seeds a failed job. Mark BLOCKED, including the "failed ZIP not offered / diagnostic links / retry produces new attempt" parts. |
| **R04** (provider-failure replay) | The Meshy provider-failure part is BLOCKED. `build_app` forces `MockProvider` (`ui_acceptance_server.py:112-116`) with no failure mode. Only Gemini `not_configured` is reachable locally. |
| **R04 / P05** (Gemini HTTP/quota/malformed/blocked/truncated replay) | ACC:92: "arbitrary HTTP/quota/malformed-provider injection is not provided". `blocked_gemini_transport` always raises (`ui_acceptance_server.py:105-106`). The F7 error cases exist only in unit tests, so they are BLOCKED here. |
| **P05** (stale or older populated fixture vs. newer manual value) | The seed writes one cache file. `--replace-seed` swaps it (`:165-166`) and `--unknown-seed` is the only variant. The UI-side overwrite-choice behavior may still be checked by hand, but a separate "older fixture" cannot be generated. The null part is supported. |
| **R05** (restart backend during processing) | The helper has no hook to hold a job mid-processing. The master saw about 3.5 s runs (MV:32), so the interruption is timing-luck. Worker recovery code is not supplied, so `processing_interrupted` handling cannot be confirmed. `retryable_processing` includes it (`app.py:48`). Treat as BLOCKED unless the parent can legitimately interrupt a run. |
| **G01** | Not helper-supported. It needs a clean checkout, `git status` and process identity, which are manual evidence. It is also not automatically satisfiable, since the install is not a frozen Python lock (ACC:108). |
| **G02, zero-requests part** | `blocked-network.jsonl` records only denied non-loopback attempts, and its absence is not proof of zero (ACC:94). It needs corroboration from server logs. The helper patches only Python `socket` in the server process, so browser traffic is not covered. |
| **S04, "unusably small/partial selection"** | No fixture or route produces this. The backend requires `island_ids` min_length=1 (`contracts.py:41`), so an empty selection is rejected by schema. Partial or small selection has no defined rejection rule in the supplied code, so mark BLOCKED unless the UI shows one. |
| **D01 "attempted Generate with unsaved edits"** | This is enforced in the frontend (`live-workspace-target-review-v2.md:35-38`), which is not supplied. The backend `/process` only checks saved state (`app.py:346-377`). Verify in the UI only. |
| **Z03** | The master's relocated run was non-GUI and finite-state only (MV:20). `viewer_inspected` stays false (`live-workspace-target-review-v2.md:65`). The native MuJoCo viewer is the parent's own step and nothing in the helpers supports it. |
| **O04** ("replay original F3 preparation condition") | The helper imports only the raw GLB and photos. There is no prior attempt, dimensions, selection or orientation (`ui_acceptance_fixture.py:1-5`). F3 failure evidence (attempt `eeb467cd…`) is not replayable. Only the "unselected/unrotated raw mesh requires review" part is exercisable. |
| **S01-S03 "photo context"** | Supported only against the three original JPEGs. EXIF-6 preview orientation is a UI observation. |

## 2. Supported local flows and fixture boundaries

- **Import (G02 partially):**
  - `python -m tools.ui_acceptance_fixture` verifies the archive SHA-256 `e828bb…` and every manifest payload, then the mesh SHA-256 `5b9ced…` (`ui_acceptance_fixture.py:22-23`, `:52-64`).
  - It copies only `reconstruction/mesh.glb` and `uploads/00-02.jpg` into a new job.
  - The job starts with status `awaiting_properties`, provider `meshy`, `synthetic=False`, `legacy_sizing_allowed=False`, and no properties, orientation, review or attempts (`:77-88`).
  - A receipt, `offline-can-fixture.json`, records hashes and `physical_measurements: false` (`:94-103`).
  - The data directory must sit under `outputs/ui-integration` (`ui_acceptance_server.py:36-40`).
- **Server:**
  - Mock settings, empty Meshy and Gemini keys, token `ui-acceptance-only`, and loopback-only sockets (`:43-57`, `:60-102`).
  - A mock reconstruction provider (`:112-116`).
  - Gemini transport raises if ever called (`:105-106`).
- **Geometry, orientation, sizing, properties and process/regenerate (S01-S03, O01-O03, P01-P02, D01-D02, R01-R02, Z01-Z02):**
  - These run on the real API routes (section 3) and real backend logic.
  - They are conditional on the frontend, which is not supplied.
  - Exports A and B are produced with the mock provider but against the raw can mesh.
- **Gemini positive (P03-P04):**
  - The seed (`--seed-job JOB_ID`) writes `suggestions/gemini.json` with 0.04/0.05/0.06 m, mass 0.08 kg and friction 0.4, all `source: estimated` (`ui_acceptance_server.py:133-155`, `:167-179`).
  - It refuses a job that is neither synthetic-mock nor a verified can fixture (`:129-132`).
  - Cache hit requires `object_hint` null/empty and no `refresh` (`suggestions.py:109-128`). Use an empty hint with no refresh.
- **Unknown (P05, partial):** `--replace-seed --unknown-seed` sets dimensions, mass and friction to null (`ui_acceptance_server.py:156-162`).
- **Gemini unavailable (R04 partial):** any different object hint is a cache miss. It then hits `not_configured` before any transport call (`suggestions.py:134-135`), and the route returns 503 (`app.py:276-277`) with `manual_entry_available: true` (`suggestions.py:76-81`).
- **Boundaries:**
  - Seeded Gemini values are synthetic and not can measurements (ACC:84).
  - They must not become three scale constraints.
  - The 100 mm Z reference the master used was diagnostic only (ACC:74, MV:19).
  - The master's browser run and the derived 22.7433 × 22.7531 × 100 mm (MV:30) are the master's own observations, not this checklist's results. Select and size independently.

## 3. Local API routes, payloads and evidence fields

All `/api/*` routes except `/api/health` need the header `Authorization: Bearer ui-acceptance-only` (`app.py:99-117`). Quote these from the saved-record responses.

- **`GET /api/jobs/{id}/geometry?preview=true`** (`target_review.py:49-62`)
  - Inventory fields: `source_mesh_sha256`, `algorithm`, `islands[]` with `id`, `label`, `node_index`, `face_count`, `vertex_count`, `bounds_input_units` (`atul-target-review-interface.md:65-69`).
  - There is no automatic selection. IDs are topology IDs, not product identity.
  - The master's pick was "Surface 3". ACC:72 says to confirm visually, not hard-code.
- **`PATCH /api/jobs/{id}/geometry-review`** (surface selection, `target_review.py:64-123`)
  - Body:
    ```json
    {"source_mesh_sha256":"…","island_ids":["<64-hex>",…],"orientation":{"x_deg":…,"y_deg":…,"z_deg":…},"review_note":"…","acknowledge_geometry":true,"expected_input_revision":N}
    ```
  - Failure responses:
    - 409 if `expected_input_revision` is stale.
    - 409 if the orientation differs from the saved orientation.
    - 409 if the source hash differs.
    - 422 for unknown islands.
    - Schema 422 for an empty list, duplicates, `acknowledge_geometry` false, or a blank note (`contracts.py:41-52`).
  - Success bumps `input_revision`, clears `sizing_result`, `active_attempt_id`, `asset`, `export_path`, `validation_path` and `bundle_path`, and sets status to `awaiting_properties`.
  - It retains prior attempts via `retained_attempts` (`:103-119`).
  - If the context changed, `properties.geometry_context_sha256` is set to null (`:97-101`). This is the S03 invalidation evidence.
  - Record: `geometry_review.{island_ids, geometry_context_sha256, reviewed_at, state="user_reviewed_not_physically_verified"}`.
- **`PATCH /api/jobs/{id}/orientation`** (`app.py:316-344`)
  - Body: `{"x_deg","y_deg","z_deg"}`, each in [-180, 180] and strict numeric (`contracts.py:31-33`).
  - Save orientation before the target review. It nulls `properties.geometry_context_sha256` and `sizing_result`, and bumps `input_revision` (`:329-333`).
  - It does not clear `geometry_review`. A mismatch is caught later with 409 "Source or orientation changed; review the target and sizing again" (`target_review.py:24-31`). That is observable after orientation change.
- **`POST /api/jobs/{id}/sizing-preview`** (one-reference uniform scaling, `app.py:172-189`)
  - Body:
    ```json
    {"geometry_context_sha256":"…","orientation":{…},"sizing":{"mode":"uniform","reviewed_orientation":{…},"reference":{"axis":"x|y|z","length":L,"unit":"mm|m","source":"…","correspondence":"full_mesh_extent","description":"…"}}}
    ```
  - Response: `dimensions_m`, `sizing_result`, and `geometry_context_sha256` (the job's current review context, or null).
  - `sizing_result` fields (`contracts.py:130-139`):
    - `mode`
    - `orientation`
    - `source_extents_input_units` (this is `D`)
    - `scale_factors` (three values, which should be equal for uniform)
    - `resulting_dimensions_m`
    - `reference_extent_input_units`
    - `geometry_review="reference_correspondence_user_supplied_not_verified"`
  - Check `scale_factors[0]==[1]==[2]` and `resulting_dimensions_m == s·D`. Compare `reference_extent_input_units` to `D[axis]`.
  - `length` must be > 0, finite and strictly numeric. Zero, negative or string values are schema 422s. Use these for O03.
  - The preview never saves anything.
  - **Risk:** `mode: "independent_axes"` plus `acknowledge_distortion: true` and no reference is accepted by the schema (`contracts.py:124-127`). Don't use it.
  - **Risk:** the preview route has no state-gating, and `dimensions_m` falls back to a `{1,1,1}` placeholder (`app.py:175-181`).
- **`PATCH /api/jobs/{id}/properties`** (saved state, `app.py:281-314`)
  - Body: `AssetProperties` with `dimensions_m`, `mass_kg {value>0, source, note}`, `sliding_friction` (nullable) or `{value>=0,…}`, `sizing`, and `geometry_context_sha256`.
  - Zero or negative mass fails with 422 (`contracts.py:157-162`). Null friction is allowed.
  - With `sizing` null and `legacy_sizing_allowed` false, the response is 422 "Choose uniform sizing…" (`:286-289`).
  - Success bumps `input_revision` and clears `sizing_result`'s outputs, `asset` and the export fields (`:296-312`).
  - Sizing is re-resolved from the server's source extents (`resolve_job_sizing`), and `sizing_result` is stored on the job.
- **`GET /api/jobs/{id}`** is the saved/draft authority. Compare after refresh and reopen:
  - `input_revision`
  - `status`
  - `orientation`
  - `geometry_review`
  - `properties` (including `sizing` and `geometry_context_sha256`)
  - `sizing_result`
  - `attempts[]`
  - `active_attempt_id`
  - `error`
  - `export_path`, `validation_path`, `bundle_path`
- **Drafts are frontend-only.** Nothing in the backend stores them. Server-side evidence of "unsaved" is simply no change in `input_revision` and no `geometry_review` or `properties` change.
- **`POST /api/jobs/{id}/process`** (generate/regenerate, `app.py:346-377`)
  - It requires status `awaiting_properties` (or a retryable failure), saved properties, and a current review whose context matches the saved properties binding.
  - 409s:
    - "Select and review the target geometry before processing" (no review)
    - "Source or orientation changed; review the target and sizing again" (stale review, from `target_review.py:24-31`)
    - "Target changed; preview and save its reference correspondence again" (stale binding)
    - "Orientation changed; review and save sizing again" (`sizing.reviewed_orientation` mismatch)
    - "Job is already processing"
  - Success returns 202 with a new immutable attempt.
- **Attempt history:** `attempts[]` entries are `RigidAttempt` (`contracts.py:214-225`):
  - `id`
  - `status`
  - `started_at`, `finished_at`
  - `inputs`, a snapshot of `input_revision`, `properties`, `orientation`, `sizing_result`, `geometry_review`, `mesh_path`, `provider_task_id`, `source_images` and `provenance` (`:201-211`)
  - `inputs_path`
  - `asset`
  - `export_path`, `validation_path`, `bundle_path`
  - `error`
  - Use `inputs.geometry_review.geometry_context_sha256`, `inputs.sizing_result` and `inputs.input_revision` to prove A and B are distinguishable.
  - `provider_task_id` should stay null for the imported fixture and mock runs.
- **`GET /api/jobs/{id}/files/{relative path}`** (`app.py:379-390`) serves artifacts. Hash A's ZIP before and after B. Use the paths from `attempts[].bundle_path` (and `export_path`, `validation_path`).
- **`GET /api/jobs/{id}/suggestions`:** 404 if no cache. **`POST …/suggestions`** with `{"object_hint": null, "refresh": false}`. Failures return 503 with `detail`, `category`, `retryable` and `manual_entry_available` (`suggestions.py:76-81`).
- **Zero-provider-call evidence:**
  - `blocked-network.jsonl` next to the data dir (`ui_acceptance_server.py:111`).
  - Server access log.
  - `GET /api/health` returns `provider: "mock"` (`app.py:191-193`).
  - Job `provider_task_id`.
  - The suggestion record's `model: "offline-synthetic-fixture"` and `acceptance_fixture: true` (`ui_acceptance_server.py:168`, `:175`).

## 4. Risks of using the manual derivative or making provider calls

**Manual derivative (F4):**
- The helper cannot import it, since it copies only `original/reconstruction/mesh.glb` and the three JPEGs (`ui_acceptance_fixture.py:54`, `:62`). The risk is a human picking F4 manually.
- F4 is `manual/reconstruction/can-selected-upright.obj`, already selected, rotated and nonuniformly resized (CL:30). Using it, or its attempt `8bd2fc4a…`, defeats S01-S03, O01, O02 and Z. CL:116 says loading the F4 ZIP does not satisfy Z.
- Verify the job mesh against `5b9ced8c…` (the receipt records it, `ui_acceptance_fixture.py:94-103`). Reject any job whose mesh is not the raw GLB.
- The 57/57/131 mm values and the old 951.2% nonuniform spread (CL:29) must not become the entered reference. The reference is one length on one axis. Entering a second axis is not possible via `SizingReference`, but a manual `dimensions_m` in the properties body is a trap: `AssetProperties.dimensions_m` is required (`contracts.py:151`). The server derives it for uniform mode (`app.py:294`), so verify the saved values equal `resulting_dimensions_m` and were not typed independently.
- Gemini's 40/50/60 mm is also not to be applied as three constraints.
- The seeder also accepts any synthetic mock job (`ui_acceptance_server.py:129`), so a leftover synthetic upload job from `POST /api/jobs` must not be mistaken for the can fixture.

**Provider calls:**
- `POST /api/jobs` (upload) still works on the acceptance server. It enqueues the mock provider and creates a synthetic cube-like job, not the can (`app.py:195-249`). A tester uploading photos creates unrelated synthetic evidence.
- Starting the server any other way is the main risk:
  - Other entry points, such as `create_app()` or `Settings.from_env()`, would read `.env`, so use only `python -m tools.ui_acceptance_server`.
  - The `--seed-job` branch does not start a server.
  - The docstring's first example runs the file by path (`ui_acceptance_server.py:3`), but ACC says `-m` because the file imports `tools.ui_acceptance_fixture`.
- The loopback guard patches only `socket` in the server process. It does not stop browser requests, so the frontend's `VITE_API_BASE_URL` must be loopback (ACC:58).
- Don't set a Gemini or Meshy key in the shell, since the helper ignores them but other tools would not. Any `blocked_external_host` log entry means investigate. Do not count it as zero (ACC:94).
- **Gemini cache traps:**
  - `refresh: true` or a non-empty hint skips the cache. With an empty key this yields `not_configured` and not a call. That is safe locally but is an "unavailable" result and not the positive fixture.
  - A cache whose `requested_model` differs from `settings.gemini_model` is treated as a miss (`suggestions.py:112-120`).
  - `--replace-seed` destroys the prior cache deliberately (`:165`), so restore the positive seed before P03/P04.
- **Meshy:** the fixture's provider label is `meshy` but no task is attached. The GET geometry and process routes never call the provider, and the job has `provider_task_id` null. The worker file is not supplied, so I can't confirm that `/process` makes no provider request. That is an inference from `app.py:346-377`. Confirm from the `provider_task_id` fields and the logs.

**Overall:** I assess nothing as PASS. Everything in sections 2 and 3 is a route the human must exercise and record.
