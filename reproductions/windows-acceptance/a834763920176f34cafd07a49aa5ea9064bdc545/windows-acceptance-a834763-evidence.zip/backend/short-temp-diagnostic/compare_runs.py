from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
root=Path(r'C:\Users\srija\calhacks-arm\outputs\windows-acceptance-results\a834763920176f34cafd07a49aa5ea9064bdc545\backend');out=root/'short-temp-diagnostic'
first=json.loads((root/'failure-summary.json').read_text());tree=ET.parse(out/'pytest-results.xml').getroot()
cases=list(tree.iter('testcase'));ids={x.get('classname')+'::'+x.get('name') for x in cases}
assert ids=={f['id'] for f in first['failures']}
assert len(cases)==25 and not any(c.find('failure') is not None or c.find('error') is not None for c in cases)
summary={'purpose':'Separately authorized environment diagnostic; does not replace the first full native run or integrated checklist pass','head':json.loads((out/'runtime.json').read_text())['head'],'short_basetemp':'C:/Users/srija/calhacks-arm/outputs/qatmp-a834','cases_selected':25,'passed':25,'failed':0,'skipped':0,'duration_seconds':58.02,'blocked_network_attempts':json.loads((out/'test-exit.json').read_text())['blocked_network_attempts'],'initial_direct_winerror206_cases_now_passed':[f['id'] for f in first['failures'] if 'WinError 206' in (f['message'] or '')],'initial_direct_winerror5_cases_now_passed':[f['id'] for f in first['failures'] if f['direct_windows_access_error']],'remaining_observed_winerror206':0,'remaining_observed_winerror5':0,'qualification':'Shorter paths remove observed path-length pressure. Disappearance of WinError5 during the separate retry does not prove a permission/locking defect is fixed. No application code changed. Initial full-suite failures remain recorded, not waived.','preserved_initial_evidence_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['pytest-full.log','pytest-results.xml','failure-summary.json']}}
(out/'comparison-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
