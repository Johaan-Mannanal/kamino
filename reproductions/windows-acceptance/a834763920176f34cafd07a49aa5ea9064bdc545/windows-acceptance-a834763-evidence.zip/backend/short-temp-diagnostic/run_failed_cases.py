from pathlib import Path
from datetime import datetime, timezone
import ipaddress,json,os,platform,sys,importlib.metadata,subprocess
sys.path.insert(0,str(Path.cwd()))
out=Path(r'C:\Users\srija\calhacks-arm\outputs\windows-acceptance-results\a834763920176f34cafd07a49aa5ea9064bdc545\backend\short-temp-diagnostic')
cleared=[]
for key in list(os.environ):
 if key.startswith(('MESHY_','GEMINI_','FETCH_AGENT_','AGENTVERSE_','PHOTO2SIM_')) or key in ('VULTR_API_KEY','SSLKEYLOGFILE'):
  cleared.append(key);os.environ.pop(key,None)
blocked=out/'pytest-blocked-network.jsonl'
def local(host):
 if host in (None,'','localhost','localhost.'):return True
 try:return ipaddress.ip_address(str(host).split('%')[0]).is_loopback
 except ValueError:return False
def audit(event,args):
 if event=='socket.connect':
  address=args[1]
  if isinstance(address,(str,bytes)):return
  host=address[0]
 elif event=='socket.getaddrinfo':host=args[0]
 else:return
 if not local(host):
  with blocked.open('a',encoding='utf-8') as f:f.write(json.dumps({'time':datetime.now(timezone.utc).isoformat(),'event':event,'host':str(host)})+'\n')
  raise PermissionError('Non-loopback network denied for isolated backend tests')
sys.addaudithook(audit)
import photo2sim,mujoco,numpy,trimesh
identity={'head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'python':platform.python_version(),'interpreter':sys.executable,'platform':platform.platform(),'app_import_path':str(Path(photo2sim.__file__).resolve()),'mujoco':mujoco.__version__,'numpy':numpy.__version__,'trimesh':trimesh.__version__,'cleared_environment_variable_names':cleared,'network_policy':'Python audit hook denies non-loopback getaddrinfo/connect before pytest import','started_at_utc':datetime.now(timezone.utc).isoformat(),'packages':sorted([{'name':d.metadata['Name'],'version':d.version} for d in importlib.metadata.distributions()],key=lambda x:x['name'].lower())}
(out/'runtime.json').write_text(json.dumps(identity,indent=2))
assert identity['head']=='a834763920176f34cafd07a49aa5ea9064bdc545'
assert Path(photo2sim.__file__).resolve().is_relative_to(Path.cwd()/'src')
import pytest
failures=json.loads((out.parent/'failure-summary.json').read_text())['failures']
cases=[f['id'].split('::',1)[0].replace('.','/')+'.py::'+f['id'].split('::',1)[1] for f in failures]
(out/'selected-cases.json').write_text(json.dumps(cases,indent=2))
code=pytest.main(['-q','-rs','--basetemp=C:/Users/srija/calhacks-arm/outputs/qatmp-a834','--junitxml='+str(out/'pytest-results.xml'),*cases])
(out/'test-exit.json').write_text(json.dumps({'exit_code':int(code),'finished_at_utc':datetime.now(timezone.utc).isoformat(),'blocked_network_attempts':len(blocked.read_text().splitlines()) if blocked.exists() else 0},indent=2))
raise SystemExit(code)

