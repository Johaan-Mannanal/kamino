from pathlib import Path
import json
root=Path(r'C:\Users\srija\calhacks-arm\outputs\windows-acceptance-results\a834763920176f34cafd07a49aa5ea9064bdc545\backend')
s=(root/'run_backend_tests.py').read_text()
s=s.replace("backend')", "backend\\short-temp-diagnostic')")
old="code=pytest.main(['-q','-rs','--basetemp='+str(out/'pytest-temp'),'--junitxml='+str(out/'pytest-results.xml')])"
new="""failures=json.loads((out.parent/'failure-summary.json').read_text())['failures']
cases=[f['id'].split('::',1)[0].replace('.','/')+'.py::'+f['id'].split('::',1)[1] for f in failures]
(out/'selected-cases.json').write_text(json.dumps(cases,indent=2))
code=pytest.main(['-q','-rs','--basetemp=C:/Users/srija/calhacks-arm/outputs/qatmp-a834','--junitxml='+str(out/'pytest-results.xml'),*cases])"""
assert old in s
s=s.replace(old,new)
(root/'short-temp-diagnostic/run_failed_cases.py').write_text(s)
