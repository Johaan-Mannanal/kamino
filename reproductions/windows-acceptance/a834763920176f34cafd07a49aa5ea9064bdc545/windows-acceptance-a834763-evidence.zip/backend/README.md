# Native Windows backend verification

Exact commit: `a834763920176f34cafd07a49aa5ea9064bdc545`.
Isolated checkout: `C:/Users/srija/calhacks-arm/outputs/acceptance-checkouts/kamino-a834763`.
Interpreter: `.venv-acceptance/Scripts/python.exe`, Python 3.12.10.
Application import: this checkout's `src/photo2sim`, verified in `runtime.json`.

## Setup

- Created a new venv. No old editable app path or installed dependency directory was copied into it.
- Initial PyPI dependency install failed on network timeouts/DNS; preserved in `dependency-preinstall.log`.
- Recovered valid public wheel payloads from the laptop's existing pip cache. `offline-wheelhouse-manifest.json` records their SHA-256 identities. An initial filename-tag recovery selected py2 for dual-tag pure wheels and was corrected to py3; that failed dependency-resolution attempt is retained in `dependency-offline-install.log`.
- Fresh offline requirements installation succeeded (`dependency-offline-install-retry.log`). A cached setuptools wheel download and isolated editable build also succeeded (`setuptools-download.log`, `editable-install.log`). `pip-check.log` reports no broken requirements.
- Main runtime: MuJoCo 3.17.0, NumPy 2.5.4, trimesh 5.2.0, FastAPI 0.162.0, Pydantic 2.14.1, Starlette 1.9.0, pytest 9.1.1. Full exact installed versions are recorded in `runtime.json`.
- Ruff check passed (`ruff-check.log`). Tracked source stayed clean (`git-status-after-setup.txt`).

## Test execution

An external QA runner first failed collection because its script directory replaced the working-directory module path: `tools` could not be found. The handoff's required `PYTHONPATH=src;.` and the QA runner's cwd path were corrected; no application/test file changed. This initial collection-only failure is retained in `pytest-collection-initial.log`.

The full native suite then ran once with:

- Exact source above.
- Provider configuration/key environment variables removed before test imports; no `.env` was copied.
- A Python audit hook rejecting non-loopback `getaddrinfo`/`connect` attempts, before pytest import. The local mocked test transports remained in use.
- `--basetemp` inside this full-SHA evidence directory.

Result: **25 failed, 365 passed, 7 skipped**, one Starlette/httpx deprecation warning, **51.76 seconds**. Pytest exit code 1.

Evidence: `pytest-full.log`, `pytest-results.xml`, `test-exit.json`, `failure-summary.json`, and the unchanged `run_backend_tests.py` QA harness.

Network: **zero blocked non-loopback attempts recorded**. No Meshy/Gemini calls were made by this test process. Registry setup was separate from test execution.

## Failure qualification

Several direct failures report Windows **WinError 206 (path too long)**. The chosen full-SHA evidence/temp root length contributes to this limit when tests add job IDs, attempt/revision IDs and staging paths. Two direct tracebacks report **WinError 5 (access denied)** at assembly bundle rename. Many dependent rigid/assembly pipeline assertions see `preparation_failed` or missing export pointers after preparation fails; these are not independently established semantic application defects.

The first full run is preserved without changing thresholds, patching code, claiming the Mac results waive it, or silently rerunning to green. A shorter-temp run would be a separately labeled environment diagnostic, not a replacement for this result. This report does not assert that every downstream assertion has a proven root cause; detailed cases and saved failed-job errors are in `failure-summary.json`.

Skipped: uagents_core unavailable; CadQuery interpreter not configured; five host symlink-permission scenarios. Details are in the JUnit/summary/log. No optional feature was installed just to suppress a skip.

The unit suite is supplementary to the integrated UI acceptance record. It does not establish can selection fidelity, persistence through the UI, ZIP download through the browser, native viewer appearance, physical geometry accuracy or grasp success.

## Evidence packaging

Exclude `offline-wheelhouse/` (about 750 MB of local cached installers) and, if size matters, `pytest-temp/` from the final compact evidence ZIP. Retain the manifest, all logs, JUnit, runtime identity, network result and this summary. No acceptance fixtures were missing from the verified tracked checkout.

## Separately authorized short-temp diagnostic

After preserving the initial full-suite result, the parent authorized one diagnostic rerun of only the 25 failed cases, at the same exact SHA and native environment with the same credential clearing/network audit guard, using a new short temp root `C:/Users/srija/calhacks-arm/outputs/qatmp-a834`.

Diagnostic result: **25 passed**, no failures/skips, one Starlette/httpx warning, 58.02 seconds. No blocked external-network attempts were recorded. No WinError206 or WinError5 remained observed in this diagnostic. The previously failing case set was verified to match exactly.

See `short-temp-diagnostic/comparison-summary.json` and its JUnit/log/runtime files. The original 25-failed full suite remains preserved above and is not replaced or waived. This diagnostic supports path-length pressure as an environmental factor. The disappearance of access-denied renames on retry does not establish that a permission/locking defect was fixed. No application code changed, and this was not a second integrated UI checklist pass.
