from pathlib import Path
from zipfile import ZipFile, BadZipFile
from email.parser import Parser
import json, shutil, hashlib
cache=Path(r'C:\Users\srija\AppData\Local\pip\Cache')
out=Path(r'C:\Users\srija\calhacks-arm\outputs\windows-acceptance-results\a834763920176f34cafd07a49aa5ea9064bdc545\backend\offline-wheelhouse')
out.mkdir(exist_ok=True)
records=[]
for path in [*cache.glob('http-v2/**/*.body'),*cache.glob('wheels/**/*.whl')]:
 try:
  with path.open('rb') as f:
   if f.read(4)!=b'PK\x03\x04':continue
  with ZipFile(path) as z:
   wheels=[n for n in z.namelist() if n.endswith('.dist-info/WHEEL')]
   if len(wheels)!=1:continue
   wheeldir=wheels[0].rsplit('/',1)[0]
   wheel=Parser().parsestr(z.read(wheels[0]).decode())
   meta=Parser().parsestr(z.read(wheeldir+'/METADATA').decode())
   tags=wheel.get_all('Tag'); tag=next((t for t in tags if t.startswith(('cp312-', 'py3-'))), tags[0])
   name=meta['Name'].replace('-','_')+'-'+meta['Version']+'-'+tag+'.whl'
   if z.testzip() is not None:continue
  target=out/name
  if not target.exists():shutil.copyfile(path,target)
  records.append({'file':name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'source':'existing local pip cache'})
 except (BadZipFile,KeyError,UnicodeError,ValueError,IndexError):pass
(out.parent/'offline-wheelhouse-manifest.json').write_text(json.dumps(records,indent=2))
print('Validated cached wheels:',len(set(r['file'] for r in records)))
for name in sorted(set(r['file'] for r in records)):print(name)

