from pathlib import Path
import json,sqlite3,xml.etree.ElementTree as ET,collections
out=Path(r'C:\Users\srija\calhacks-arm\outputs\windows-acceptance-results\a834763920176f34cafd07a49aa5ea9064bdc545\backend')
root=ET.parse(out/'pytest-results.xml').getroot();failures=[];skips=[]
for case in root.iter('testcase'):
 f=case.find('failure')
 if f is not None:
  text=f.text or '';messages=[line.strip() for line in text.splitlines() if line.strip().startswith(('E ','E\t','E:'))]
  failures.append({'id':case.get('classname')+'::'+case.get('name'),'message':f.get('message'),'direct_windows_access_error': 'WinError 5' in text,'assertion_evidence':messages[-4:]})
 skip=case.find('skipped')
 if skip is not None:skips.append({'id':case.get('classname')+'::'+case.get('name'),'message':skip.get('message')})
errors=[]
for db in (out/'pytest-temp').rglob('*.sqlite3'):
 try:
  with sqlite3.connect(str(db)) as con:
   tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
   for table in tables:
    columns=[r[1] for r in con.execute('PRAGMA table_info("'+table.replace('"','""')+'")')]
    if 'record' not in columns:continue
    for row in con.execute('SELECT record FROM "'+table.replace('"','""')+'"'):
     record=json.loads(row[0]);error=record.get('error')
     if error:errors.append({'fixture_directory':db.relative_to(out/'pytest-temp').parts[0],'table':table,'status':record.get('status'),'error':error})
 except Exception:pass
report={'result':{'failed':25,'passed':365,'skipped':7,'seconds':51.76},'failures':failures,'skips':skips,'saved_failed_job_records':errors,'blocked_network_attempts':json.loads((out/'test-exit.json').read_text())['blocked_network_attempts'],'direct_windows_access_error_count':sum(f['direct_windows_access_error'] for f in failures)}
(out/'failure-summary.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
