"""Package a curated immutable snapshot, excluding dependency/cache trees."""
import hashlib, json, zipfile
from pathlib import Path
from datetime import datetime, timezone
root=Path(__file__).resolve().parent
destination=root.parent/'windows-acceptance-a834763-evidence.zip'
assert not destination.exists(), 'Preserve existing finalized package; do not overwrite'
selected=[]
for p in root.iterdir():
    if p.is_file() and (p.suffix in {'.md','.json','.txt','.log','.py'} or p.name=='can-fixture.zip') and p.name!='MANIFEST.json': selected.append(p)
for folder in ['api','ui','exports','attempt-records','pinned-docs','claude-review-sandbox']:
    selected += [p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for folder in ['backend','frontend','setup']:
    selected += [p for p in (root/folder).iterdir() if p.is_file() and p.name!='pinned-source.zip']
selected += [p for p in (root/'backend/short-temp-diagnostic').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
payload={str(p.relative_to(root)).replace('\\','/'):p.read_bytes() for p in sorted(set(selected))}
for name in payload:
    assert not any(part in name.split('/') for part in ['node_modules','.venv-acceptance','offline-wheelhouse','pytest-temp','prefetch','.env','__pycache__'])
    assert 'pinned-source.zip' not in name
manifest={'commit':'a834763920176f34cafd07a49aa5ea9064bdc545','created_at_utc':datetime.now(timezone.utc).isoformat(),'scope':'Curated evidence snapshot of the one Windows acceptance pass. Live logs may advance afterward.','exclusions':['dependency stores','offline-wheelhouse binaries','venvs','node_modules','pytest temporary trees','incomplete setup/pinned-source.zip','duplicate extracted archive-evidence (original can-fixture.zip included once)','credentials/env files'],'files':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(payload.items())]}
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
(root/'MANIFEST.json').write_bytes(manifest_bytes)
with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,data in sorted(payload.items()): z.writestr(name,data)
    z.writestr('MANIFEST.json',manifest_bytes)
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None
    for item in manifest['files']:
        data=z.read(item['path'])
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
digest=hashlib.sha256(destination.read_bytes()).hexdigest()
checksum=destination.with_suffix('.zip.sha256')
checksum.write_text(digest+'  '+destination.name+'\n')
print(json.dumps({'archive':str(destination),'bytes':destination.stat().st_size,'payload_files':len(payload),'sha256':digest,'checksum':str(checksum),'crc_and_manifest_verified':True},indent=2))
