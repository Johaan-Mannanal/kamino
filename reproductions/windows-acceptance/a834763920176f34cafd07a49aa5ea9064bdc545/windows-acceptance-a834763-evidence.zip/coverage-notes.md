# Acceptance coverage notes (source review, not execution)

Pinned source: `a834763920176f34cafd07a49aa5ea9064bdc545`.
All actual acceptance results remain parent-owned. No PASS is claimed from this review.

## Unsupported or partial integrated scenarios

- **R03:** the delivered offline helper has no integrated preparation/export/validation-failure injection route. Existing frontend `validation_failure` UI mocks and backend unit fixtures are supplementary, not a substitute. Mark BLOCKED unless a supplied supported integrated failure route is actually available; do not edit app code or fixture database to manufacture failure.
- **R04:** Gemini-unavailable is supported (cache miss + explicit empty key yields local `not_configured`). Actual reconstruction-provider failure is not supplied by the helper: it uses `MockProvider`, and the imported can already has a cached raw mesh and no provider task. Thus a combined row cannot be PASS solely from the Gemini half or standalone UI mock; record supported observations and BLOCKED provider-failure portion.
- **P05:** null suggestions and local unavailable are supported. Arbitrary malformed/truncated/billing/quota/provider HTTP/network errors are not provided by this integrated helper; those portions are BLOCKED, even if unit tests cover them. Newer manual edit versus older positive cached response may still be exercised in the UI. Avoid replacing an aggregate row with unqualified PASS when required subscenarios were not executed.
- **R05:** a stop/restart of the acceptance service is technically possible, but no deterministic in-flight interruption fixture/hook is provided. If a genuine in-flight local processing state and recovery cannot be captured without app/database modification, mark the interrupted-processing subscenario BLOCKED. Do not use the D04 connection failure or a completed-job reopen as proof of in-flight recovery.
- **S04:** empty selection and whole-island selection are supported in the model. Arbitrary partial-surface cutting/cropping is not implemented by the inventory helper; the clause is conditional on UI support. Do not invent a cut operation. A tiny existing island is valid geometry, and source review alone does not establish how the UI labels its semantic suitability.
- **O04:** importer intentionally strips old sizing, selection, orientation and prior attempts. The exact historic 951.2% malformed export remains archive evidence, not a hydrated current acceptance job. All-components/unrotated inspection is supported using F2; a demand to replay old legacy saved state verbatim may be BLOCKED if no supplied import route exists. Never force 57/57/131 mm as independent targets to create a failure.
- **D04** is supported without a custom injector: handoff instructs stop only the isolated acceptance backend, attempt a save, restart and explicitly retry. Observe saved versus draft behavior and record actual requests. This does not establish R05.

## Useful local routes and fields for evidence (observe UI first)

Use only localhost acceptance port 8001 and the dummy local token `ui-acceptance-only`; omit Authorization from shared traces.

- `GET /api/health` reports the helper provider (`mock`). The imported raw can remains `job.provider=meshy`, `synthetic=false` because it is photo-derived, despite no live provider being enabled. Do not treat that provenance as a network call.
- `GET /api/jobs/{id}`: capture complete snapshots after each UI save. Useful fields: `input_revision`, `orientation`, `geometry_review`, `properties`, `sizing_result`, `active_attempt_id`, `attempts`, artifact paths, error/status.
- `GET /api/jobs/{id}/geometry?preview=true`: inventory has `source_mesh_sha256`, `algorithm`, `islands` with `id`, `label`, counts/bounds; preview adds `geometry[id] = {vertices, faces}`. Confirm target visually rather than hard-coding Surface 3.
- `PATCH /api/jobs/{id}/orientation`: `{x_deg,y_deg,z_deg}` in degrees. Orientation saves increment input revision, clear sizing result and current outputs, retain attempts and invalidate properties' geometry binding.
- `PATCH /api/jobs/{id}/geometry-review`: `{source_mesh_sha256,island_ids,orientation,review_note,acknowledge_geometry:true,expected_input_revision}`. Reply contains `geometry_review.geometry_context_sha256` and updated input revision. Stale/mismatched source/orientation/revision yields 409; invalid selection yields 422. Selection changes clear sizing result/current outputs and retain old attempts.
- `POST /api/jobs/{id}/sizing-preview`: `{orientation,geometry_context_sha256,sizing:{mode:'uniform',reviewed_orientation:{...},reference:{axis:'z',length:<reviewed>,unit:'mm',source:'estimated',correspondence:'full_mesh_extent',description:<review note>}}}`. Optional `dimensions_m` is not an independent three-axis target in uniform mode. Capture `sizing_result.source_extents_input_units`, `scale_factors` (all equal), `reference_extent_input_units`, `resulting_dimensions_m` and returned context. Preview is not a save.
- `PATCH /api/jobs/{id}/properties`: full properties include `dimensions_m`, `mass_kg`, optional `sliding_friction`, uniform `sizing` and `geometry_context_sha256`; server recomputes derived dimensions. Capture the actual UI request instead of synthesizing saves to stand in for UI behavior.
- `POST /api/jobs/{id}/process` claims immutable attempt with saved input revision/context. `attempts[*].inputs` preserves properties/orientation/sizing/geometry/source. Old attempt paths remain independently downloadable via `GET /api/jobs/{id}/files/{path}`. Hash A before B and redownload A after B.
- `GET /api/jobs/{id}/suggestions` returns saved cache; `POST .../suggestions` with empty hint / no forced refresh reuses seeded known/null cache. A different hint is cache miss and returns local unavailable; no cloud transport is allowed. Helper `--replace-seed --unknown-seed` only replaces suggestion cache, not properties; inspect UI drafts and saved API state separately.

## Isolation/evidence cautions

- `tools.ui_acceptance_fixture` verifies archive checksum + every manifest payload and imports only original raw GLB + three JPEGs. Capture `offline-can-fixture.json` receipt and raw/photograph hashes. It does not import manual derivative, dimensions, selection, orientation, task ID, or attempts.
- Data path must be under the isolated checkout's `outputs/ui-integration/`. Never reuse original live job or its database.
- `tools.ui_acceptance_server` builds explicit empty Meshy/Gemini keys, uses MockProvider and patches Python socket DNS/connect to loopback only. `blocked-network.jsonl` records denied attempts. Absence alone means no denied socket was recorded, not a comprehensive browser network proof; combine it with logs, explicit settings and browser request evidence.
- Sizing is one reviewed reference extent, one factor on every axis, other dimensions derived. Historical 57/57/131 mm and manual nonuniform derivative are comparison evidence only. Physical accuracy remains unverified.

## Claude supplemental review completed

Claude Code 2.1.302 completed the user-approved restricted read-only review. Exact output is `claude-review-result.json`; a readable extract is `claude-review.md`. Input source hashes and approval history are in `claude-review-inputs.json`, and the exact prompt is in `claude-review-sandbox/review-prompt.txt`. Its inference call was separate from the provider-free app acceptance; it had only Read/Glob/Grep tools and no app execution/UI/browser/network-provider tools.

Do not adopt these Claude claims without qualification:

- G01 identity and Z03 native viewer checks are manual/UI acceptance work, not inherently BLOCKED merely because they are absent from the offline helper or the 13-file review sandbox.
- The older cached-positive estimate versus newer manual draft portion of P05 is supported by seeding the positive cache before making the manual draft, then applying that same cached response. No separate fixture generation is needed. Arbitrary malformed/quota/HTTP provider scenarios remain unsupported.
- One historical estimated length may be explicitly reviewed as the sole reference with honest estimated provenance; the prohibition is on treating the triplet as measured ground truth or forcing all axes independently, not on every use of an estimated scalar reference.
- An actual in-flight interruption and recovery captured by the parent can support R05; lack of an artificial hold hook is not by itself proof of failure. If the required interruption cannot be captured without modifying code or data, use BLOCKED.

No review finding is a checklist PASS. Parent owns observed execution results.
