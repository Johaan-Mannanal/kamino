# Kamino conversation and mobile-review handoff

Prepared 2026-10-25 for moving the active work context to another laptop. This is a condensed history based on the conversation available in this task; it is not a verbatim transcript. The focused mobile evidence and report are included alongside this document.

## Product and ownership context

The project is now named Kamino. Keep existing API contracts, `photo2sim` imports, `PHOTO2SIM_*` configuration and saved-format identifiers compatible. Master/Johaan owns sizing and correction/regeneration/backend target-review work; Atul's separate UI branch owns Figma/layout and selected frontend changes. Do not merge into Johaan's active checkout, do not overwrite earlier branches, and do not deploy absent authorization. Bright Data is queued separately; optional CAD inputs are a later improvement. Srijan completed the earlier independent Windows charger inspection. Sponsors/deployment remain deferred.

## Earlier Gemini and charger work

- The initial Gemini assignment covered reliability/fallback: configurable `gemini-3.8-flash` to `gemini-3.6-flash`, bounded retries and total deadline, classified provider failures, strict response validation, preserving manual entry, recording actual model/fallback provenance, and caching fallback results. Credentials were never to be logged.
- The Gemini delivery was reviewed by Master as commit `057ea6333d9ed383ed0c878c8da3f6aee1f5550e`; Master reported 88 focused tests passing, ancestry from `c38c95c`, and no scoped blocker. The expected delivery is to remain independent; no additional provider calls/features were requested.
- Charger reconstruction handoff went through a manual user-mediated transfer. Master later confirmed receipt and verified both archive SHA-256 values, declared input hashes, and matching job/asset identity. The supplement's 280-passed/4-skipped result and synthetic live Gemini successes for both configured models were reviewed. No further charger transfer, private-photo resend, live provider call, Meshy reconstruction, or paid reconstruction is part of this task.

## Candidate and combined compatibility work

- The frozen combined candidate is `a834763920176f34cafd07a49aa5ea9064bdc545`, branch `codex/combined-release-20261025`. Master independently reconstructed it, checked 511 source hashes and passed 113 focused tests. Its source identity was reported as `d4107843fcd8d6fe3d5c8aa087a7a3960ee32e2e1b0c3689eb16e31f1be3abf1`.
- The request was to verify this candidate against `c38c95c7211b790dfd7c624f7482b9eaabb0ce58`, not replay/merge deliveries. It includes target-review v2 and the fix that avoids full geometry reload on every automatic-processing poll.
- Figma redesign was tracked separately at `https://www.figma.com/design/rSOvF7zmhYyGwLxGqLRgAo/Untitled?node-id=0-1&m=dev`. Kamino branding was reconciled to checkpoint `724867cea2497a571002e6d0d9ac46d64b604c6f`; overlapping branding commit `fa8db8626b6b84b7e6b5af58cebac9eee01b3501` and `outputs/handoffs/kamino-branding/branding-only.patch` (SHA-256 `09d983a4d786c7e8268bc54edddc3500011726cecaeb35f76ad67feb6b118386`) were identified as overlapping. The cumulative branding patch was not applied over the frozen candidate.
- An isolated UI report archive `kamino-master-handoff-692cba4.zip` was previously prepared; its recorded SHA-256 is `ce5cef00503a06c7d4f9434838ed7ca2c90eae9cf615edbc457a07e4d0b1b4d2`. Earlier UI branches include `codex/kamino-v9-api` at `90b1437f264612d7ddb99a4d53ff971fd8d72248` and `codex/kamino-ui-master-report` at `692cba4314be063594f53eac149d1fdd31e9ce91`. They were not altered by this mobile review.
- Figma/layout ownership was separated from Johaan's reserved `target-review.ts`, its tests and correction hook. Master later requested the incremental UI handoff be assessed against frozen `a834763`, with specific review of automatic Gemini, Save & generate, target/reference invalidation and preserved downloads. The master is reviewing newer UI changes; those changes need a fresh mobile pass when integrated.

## Local end-to-end UI/backend exploration

- The user supplied local API keys in `.env` (the actual values are deliberately not repeated here). The UI/backend were explored through local browser ports including `5188`, `5190`, and older UI port `5174/5175`; several tabs were noted. User-reported keys-saved state is not evidence that credentials should be included in this handoff.
- The user asked why Save and Generate was disabled. The workspace requires explicit orientation review/save, target selection/review and full-extent reference correspondence/acknowledgement, then saved properties. A mismatch/unsaved review correctly blocks new generation, but some displayed Saved labels were found misleading in the frozen candidate; see mobile findings below.
- The later combined Save & generate behavior belongs to newer UI work and was not accepted merely because the older separate Save reviewed properties / Generate actions worked. Preserve manual drafts, warnings, attempt history and prior downloads, and keep optional Gemini estimates distinct from user-confirmed/saved properties.
- The user asked for a fresh branch/commit. UI work has remained on isolated branches; pushing was previously declined by user in favor of sharing a patch. No push or deployment is performed by this mobile check.

## Current focused mobile review

- Candidate tested: exact frozen `a834763920176f34cafd07a49aa5ea9064bdc545`, `prototypes/kamino-ui`. No application source change was made.
- Isolated report branch: `codex/mobile-a834763-review`; commit `b81faf1f10081c186f12e19bc52cca6954864da1`. The commit adds only `docs/handoffs/mobile-a834763-review.md`. It is report-only, not a UI fix. Frontend, Kamino UI prototype, `src`, tests and tools Git trees all match the frozen candidate exactly.
- Tested through desktop in-app-browser viewport emulation on Windows 11, not a real phone: 320x568, 390x844, 430x932 portrait and 844x390 landscape. Device touch, native keyboard, mobile browser, iOS/Android, accessibility screen readers and safe areas remain unverified.
- Isolated local backend/UI ran with a mock geometry provider, empty Gemini/Meshy keys, outbound networking blocked and a synthetic gray-square upload. No `.env` or private photos/provider secrets were loaded. A mock three-box mesh supported explicit target selection, reference sizing, orientation saving, generation, warnings, two attempts, downloads, reload and a no-key Gemini error. This is not reconstruction, charger/can validation, live Gemini, or physical accuracy verification.
- Successful workflow evidence: selected/excluded geometry remained explicit; changing target/orientation invalidated review/reference and blocked new Generate while numeric drafts survived; saving/re-review reopened generation; two generations passed the candidate's numerical validation scope; prior exports stayed accessible after another target edit; history and reload behavior worked. Gemini `not_configured` was sanitized and manual draft saving remained usable.
- Issues M01-M07 are detailed with screenshots and measurements in `mobile-a834763-review.md`: M01 toolbar controls are clipped at portrait widths despite no document-wide horizontal overflow; M02 some selection rows/control typography are small/dense; M03 long page scrolling separates photos/viewer/forms/actions and copy refers to a “left column”; M04 header/footer can say Saved while target review is unsaved, though generation is blocked; M05 viewer preview can say unsaved just after properties saved; M06 detailed asset/export warnings are not shown inline; M07 processing-state copy can imply saving is still required while generation runs.
- The newer UI should be rechecked for automatic Gemini cache/attempt behavior, Save & generate retaining target-review and race/stale-result safeguards, invalidation/dirty labels/download access, geometry polling/revalidation, responsive toolbar/photo/preview/warning/history/download layout and real-device interaction. In particular, the frozen candidate does not test the newer combined Save & generate button.
- There is no direct Master/Johaan chat endpoint available to this host. The report is prepared for manual forwarding by the user.

## Final mobile evidence bundle

- ZIP: `kamino-mobile-a834763-20261025.zip` in the repository's `artifacts` folder.
- SHA sidecar: `kamino-mobile-a834763-20261025.zip.sha256`.
- The package contains the report, 29 screenshots, browser geometry/workflow snapshots, API and attempt/hash results, runtime/source record, sanitized logs, manifest, and report-only patch. It omits temporary harness scripts, private photos, provider credentials, dependencies and fixture database.
- No unit/full suite was run for this focused mobile task; it was an interactive synthetic workflow check. The 113/280/4 and prior 88-test results above were reported in earlier independent work, not rerun here.
- No shared candidate, deployment, existing archive, or previous UI branch was changed. The isolated review servers were stopped after evidence capture.
