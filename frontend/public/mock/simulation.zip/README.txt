SYNTHETIC UI FIXTURE. No reconstruction or validation was run.
